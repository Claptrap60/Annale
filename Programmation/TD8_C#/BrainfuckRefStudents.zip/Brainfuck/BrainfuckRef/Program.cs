﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;

namespace BrainfuckRef
{
    class Program
    {
        [STAThread]
        public static Dictionary<char, char> classicBrainfuck()
        {
            Dictionary<char, char> brainfuck = new Dictionary<char, char>();
            brainfuck.Add('>', '>');
            brainfuck.Add('<', '<');
            brainfuck.Add('+', '+');
            brainfuck.Add('-', '-');
            brainfuck.Add('.', '.');
            brainfuck.Add(',', ',');
            brainfuck.Add('[', '[');
            brainfuck.Add(']', ']');
            
            return brainfuck;
        }
        public static Dictionary<char, char> notClassicBrainfuck()
        {
            Dictionary<char, char> brainfuck = new Dictionary<char, char>();
            brainfuck.Add('>', 'a');
            brainfuck.Add('<', 'b');
            brainfuck.Add('+', 'c');
            brainfuck.Add('-', 'd');
            brainfuck.Add('.', 'e');
            brainfuck.Add(',', 'f');
            brainfuck.Add('[', 'g');
            brainfuck.Add(']', 'h');
            
            return brainfuck;
        }
        
        public static void Main(string[] args)
        {

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new IDE());

            /*
            Dictionary<char, char> brainfuck = classicBrainfuck();
          //string code = System.IO.File.ReadAllText("code.txt");

            string code = Brainfuck.generate_code_from_text("Coucou les sups c'est vos ACDC qui vous parlent!", brainfuck);
            Console.WriteLine("Before shorten_code: " + code.Length + " chars...");
            Console.WriteLine(code);
            Console.WriteLine("Execution:");
            Console.WriteLine(Brainfuck.interpret(code, brainfuck));
            
            code = Brainfuck.shorten_code(code, brainfuck);
            Console.WriteLine("After shorten_code: " + code.Length + " chars...");
            Console.WriteLine(code);
           // code = "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++.>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.------.--------.>+.>.";
            
            Console.WriteLine("Execution:");
            Console.WriteLine(Brainfuck.interpret(code, brainfuck));
      //      HuffmanCode h = new HuffmanCode(code);
      //      h.print_code();

      //      Console.WriteLine(h.huffman_program);
         //   Console.WriteLine(h.get_brainfuck_from_huffman(h.huffman_program) == h.program);

//            Console.WriteLine("After Huffman : " + h.huffman_program.Length + " chars...");



//            Brainfuck.interpret(code);
*/
        }

        
    }
}
