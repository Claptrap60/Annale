﻿using System;
using System.Collections.Generic;

namespace BrainfuckRef
{
    class BrainfuckRef
    {
        public static string Interpret(string code, Dictionary<char, char> symbols)
        {
            string ret = "";
            int position = 15000;
            int[] cells = new int[30000];
            int borne_sup = 256;
            int borne_inf = 0;

            for (int i = 0; i < cells.Length; i++)
            {
                cells[i] = 0;
            }

            List<int> posboucle = new List<int>();

            for (int i = 0; i < code.Length; i++)
            {
                if (code[i] == symbols['>'])
                    position = position == cells.Length - 1 ? 0 : position + 1;
                else if (code[i] == symbols['<'])
                    position = position > 0 ? position - 1 : cells.Length - 1;
                else if (code[i] == symbols['+'])
                    cells[position] = cells[position] == borne_sup ? borne_inf : cells[position] + 1;
                else if (code[i] == symbols['-'])
                    cells[position] = cells[position] == borne_inf ? borne_sup : cells[position] - 1;
                else if (code[i] == symbols['.'])
                    ret += (char) cells[position];
                else if (code[i] == symbols[','])
                    cells[position] = (char) Console.ReadKey(true).KeyChar;
                else if (code[i] == symbols['['])
                {
                    int pos = 0;
                    if (cells[position] == 0)
                    {
                        for (int j = 1; j < code.Length; j++)
                        {
                            if (code[i + j] == symbols['['])
                                pos++;
                            else if (code[i + j] == symbols[']'] && pos != 0)
                                pos--;
                            else if (code[i + j] == symbols[']'] && pos == 0)
                                i += j + 1;
                                break;
                        }
                    }
                    else
                        posboucle.Add(i);
                }
                else if (code[i] == symbols[']'])
                {

                    if (cells[position] != 0)
                        i = posboucle[posboucle.Count - 1];
                    else
                        posboucle.RemoveAt(posboucle.Count - 1);
                }
		else
		{
			throw new ArgumentException("Unknown char");
		}
            }

            return ret;
        }
        public static string GenerateCodeFromText(string text, Dictionary<char, char> symbols)
        {
            string program = "";
            foreach (char c in text)
                program += generate_loop_number(c, symbols); //Easy, working, but yet not very efficient solution. Nothing more was actually asked
            
            return program;
        }

        private static string generate_loop_number(int n, Dictionary<char, char> symbols)
        {
            return new string(symbols['+'], n) + symbols['.'] + symbols['['] + symbols['-'] + symbols[']'];
        }

        private static string build_mult(int a, int b, Dictionary<char, char> symbols)
        {
            return "" + symbols['>'] + new string(symbols['+'], a)
                   + symbols['[']
                   + symbols['<']
                   + new string(symbols['+'], b)
                   + symbols['>']
                   + symbols['-']
                   + symbols[']']
                   + symbols['<'];
        }

        public static string ShortenCode(string program, Dictionary<char, char> symbols)
        {
            string new_prog = "";

            for (int i = 0; i < program.Length; i++)
            {
                if (program[i] == symbols['+'])
                {
                    int buff = i++;
                    int cpt = 1;
                    while (program[i] == symbols['+'])
                    {
                        i++;
                        cpt++;
                    }

                    bool enter = false;
                    for (int k = 9; k > 5; k--)
                    {
                        if (cpt % k == 0)
                        {
                            new_prog += build_mult(k, cpt / k, symbols);
                            enter = true;
                            i = buff + cpt - 1;
                            break;
                        }
                    }

                    if (!enter)
                    {
                        i = buff;
                        new_prog += symbols['+'];
                    }
                }
                else
                {
                    new_prog += program[i];
                }
            }
            return new_prog;
        }
    }
}
