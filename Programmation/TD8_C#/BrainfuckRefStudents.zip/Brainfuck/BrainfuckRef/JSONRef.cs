﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.IO;
using System.Runtime.InteropServices;

namespace BrainfuckRef
{
    

    class JSONElement
    {
        public enum JSONType
        {
            DIC,
            LIST,
            STR,
            NB,
            BOOL,
            NULL
        }
        
        private JSONType type;
        
        public bool bool_value;
        public int int_value;
        public string string_value;
        public List<JSONElement> data;
        public List<string> key;

        public JSONElement(JSONType type)
        {
            this.type = type;
            if (type == JSONType.LIST || type == JSONType.DIC)
                this.data = new List<JSONElement>();
            if (type == JSONType.DIC)
                this.key = new List<string>();
        }

        public JSONType Type
        {
            get { return this.type; }
        }
        
    }

    static class JSON
    {

        public static JSONElement.JSONType GetJsonType(char c)
        {
            JSONElement.JSONType type;
            if (c == '{')
                type = JSONElement.JSONType.DIC;
            else if (c == '[')
                type = JSONElement.JSONType.LIST;
            else if (c == '"')
                type = JSONElement.JSONType.STR;
            else if ((c >= '0' && c <= '9') || c == '-')
                type = JSONElement.JSONType.NB;
            else if (c == 't' || c == 'f')
                type = JSONElement.JSONType.BOOL;
            else
                type = JSONElement.JSONType.NULL;
            return type;
        }

        // All strings will be correctly formated
        public static string ParseString(string json, ref int index)
        {
            int start = ++index;
            while (index < json.Length && json[index] != '"')
	        {
		        if (json[index] == '\\')
			        index++;
                index++;
	        }
            string ret = json.Substring(start, index - start);
            index++;
            return ret;
        }

        //Admitting int will be correctly written
        // this function does not detect errors like this : -5--879-597 for example;
        // neither int overflow
        public static int ParseInt(string json, ref int index)
        {
            int start = index;
            while (index < json.Length && 
                  ((json[index] >= '0' && json[index] <= '9') || json[index] == '-'))
                index++;
            string str_val = json.Substring(start, index - start);
            return int.Parse(str_val);
        }

        //A better behaviour would be to check the whole token to ensure it really is true/false
        //And throw an exception if it is not.
        public static bool ParseBool(string json, ref int index)
        {
            bool ret = json[index] == 't';
            if (json[index] == 't')
                index += 4;
            else
                index += 5;
            return ret;
        }

        public static void EatBlank(string json, ref int index)
        {
            while (json[index] == ' ' || json[index] == '\t' || json[index] == '\n')
                index++;
        }

        //Simple function to determine if two JSONElement are identical.
        //Don't worry, It was not asked in the TP
        public static bool r_equal_(JSONElement a, JSONElement b)
        {
            if ((int)a.Type != (int)b.Type)
                return false;
            if (a.Type == JSONElement.JSONType.BOOL && a.bool_value != b.bool_value)
                return false;
            if (a.Type == JSONElement.JSONType.NB && a.int_value != b.int_value)
                return false;
            if (a.Type == JSONElement.JSONType.STR && a.string_value != b.string_value)
                return false;
            if (a.Type == JSONElement.JSONType.LIST)
            {
                for (int i = 0; i < a.data.Count; ++i)
                    if (!r_equal_(a.data[i], b.data[i]))
                        return false;
            }
            if (a.Type == JSONElement.JSONType.DIC)
            {
                for (int i = 0; i < a.data.Count; ++i)
                    if (!r_equal_(a.data[i], b.data[i]) || a.key[i] != b.key[i])
                        return false;
            }
            return true;
        }

        // don't forget to eat blank "all the time", as the following JSON input is valid:
        // " {  \"test\"  :  true  ,  \"spaces\"  :  \"everywhere\"   }  "
        public static JSONElement ParseJSONString(string json, ref int index)
        {
            if (index >= json.Length)
                return null;
            EatBlank(json, ref index);
            JSONElement.JSONType type = GetJsonType(json[index]);
            JSONElement el = new JSONElement(type);
            if (type == JSONElement.JSONType.BOOL)
                el.bool_value = ParseBool(json, ref index);
            else if (type == JSONElement.JSONType.NB)
                el.int_value = ParseInt(json, ref index);
            else if (type == JSONElement.JSONType.STR)
                el.string_value = ParseString(json, ref index);
            else if (type == JSONElement.JSONType.LIST)
            {
                do
                {
                    index++; // To eat the '[' or ',' char
                    EatBlank(json, ref index);
                    el.data.Add(ParseJSONString(json, ref index));
                    EatBlank(json, ref index);
                } while (json[index] != ']');
                index++; // To eat the ']'
            }
            else if (type == JSONElement.JSONType.DIC)
            {
                do
                {
                    index++; // To eat the '{' or ',' char
                    EatBlank(json, ref index);
                    string vl = ParseJSONString(json, ref index).string_value; //Either this,
                    // or just ParseString.
                    el.key.Add(vl);
                    EatBlank(json, ref index);
                    index++; // To eat the ',' char
                    EatBlank(json, ref index);
                    el.data.Add(ParseJSONString(json, ref index));
                    EatBlank(json, ref index);
                } while (json[index] != '}');
                index++; // To eat the '}'
            }
            return el;
        }
        
        public static JSONElement ParseJSONFile(string file)
        {
            string data = File.ReadAllText(file);
            int start = 0;
            return ParseJSONString(data, ref start);
        }

        public static void PrintJSON(JSONElement el)
        {
            if (el == null)
                return;
            if (el.Type == JSONElement.JSONType.NULL)
                Console.WriteLine("null");
            else if (el.Type == JSONElement.JSONType.STR)
                Console.WriteLine("\""+el.string_value+"\"");
            else if (el.Type == JSONElement.JSONType.BOOL)
                Console.WriteLine(el.bool_value ? "true" : "false"); //Do not be afraid of ternary
            else if (el.Type == JSONElement.JSONType.DIC)
            {
                Console.WriteLine("{");
                
                for (int i = 0; i < el.key.Count; ++i)
                {
                   Console.Write("\""+el.key[i]+"\" : "); 
                   PrintJSON(el.data[i]);
                   if (i + 1 != el.key.Count)
                        Console.WriteLine(",");
                }
                
                Console.WriteLine("}");
            }
            else if (el.Type == JSONElement.JSONType.LIST)
            {
                Console.WriteLine("[");
                
                for (int i = 0; i < el.data.Count; ++i)
                {
                   PrintJSON(el.data[i]);
                   if (i + 1 != el.data.Count)
                        Console.WriteLine(",");
                }
                
                Console.WriteLine("]");
            }
            else if (el.Type == JSONElement.JSONType.NB)
                Console.WriteLine(el.int_value);
        }
        
        public static JSONElement SearchJSON(JSONElement element, string key)
        {
            if (element == null)
                return null;
            if (element.Type == JSONElement.JSONType.LIST || element.Type == JSONElement.JSONType.DIC)
            {
                for (int i = 0; i < element.data.Count; ++i)
                {
                    if (element.Type == JSONElement.JSONType.DIC && element.key[i] == key)
                        return element.data[i];
                    JSONElement rec = SearchJSON(element.data[i], key);
                    if (rec != null)
                        return rec;
                }
            }
            return null;
        }
    }   
}
