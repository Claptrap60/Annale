﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EvalExpr
{
    public static class Lexer
    {

        public static Token Tokenize(ref int pos, string expr)
        {
            //FIXME
            throw new NotImplementedException();
        }
        
        public static List<Token> Lex(string expr)
        {
            //FIXME
            throw new NotImplementedException();
        }
    }
}