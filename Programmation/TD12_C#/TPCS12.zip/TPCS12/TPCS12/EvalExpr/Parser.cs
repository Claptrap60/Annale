﻿using System;
using System.Collections.Generic;
using System.Data;

namespace EvalExpr
{
    public static class Parser
    {
        public static INode Parse(string expr)
        {
            //FIXME
            throw new NotImplementedException();
        }
    }
}