﻿using System;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace List
{
    public class Node<T>
    {
        protected T data_;
        protected Node<T> next_;
        protected Node<T> prev_;

        public Node(T elt)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public T Data
        {
            get { /*FIXME*/ throw new NotImplementedException(); }
            set { /*FIXME*/ throw new NotImplementedException(); }
        }

        public Node<T> Next
        {
            get { /*FIXME*/ throw new NotImplementedException(); }
            set { /*FIXME*/ throw new NotImplementedException(); }
        }

        public Node<T> Prev
        {
            get { /*FIXME*/ throw new NotImplementedException(); }
            set { /*FIXME*/ throw new NotImplementedException(); }
        }
    }
}