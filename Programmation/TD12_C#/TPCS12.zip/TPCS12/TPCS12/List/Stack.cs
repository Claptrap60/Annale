﻿using System;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace List
{
    public class Stack<T> //FIXME 
    {
        public Stack()
            : base()
        {}
        
        public Stack(T elt)
            : base() //FIXME
        {}
        
        public T front()
        {
            //FIXME
            throw new NotImplementedException();
        }
        
        public void popFront()
        {
            //FIXME
            throw new NotImplementedException();
        }
        
        public void pushFront(T elt)
        {
            //FIXME
            throw new NotImplementedException();
        }
    }
}