﻿using System;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace List
{
    public class List<T>
    {
        protected Node<T> head_;
        protected Node<T> tail_;

        public List()
        {
            //FIXME
            throw new NotImplementedException();
        }

        public List(T data)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public void print()
        {
            //FIXME
            throw new NotImplementedException();
        }
 
        public T this[int i]
        {
            get
            {
                //FIXME
                throw new NotImplementedException();
            }
            set
            {
                //FIXME
                throw new NotImplementedException();
            }
        }

        public void insert(int i, T value)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public void delete(int i)
        {
            //FIXME
            throw new NotImplementedException();
        }
    }
}