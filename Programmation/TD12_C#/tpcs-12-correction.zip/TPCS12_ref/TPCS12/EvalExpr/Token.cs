﻿using System;
using System.Runtime.Remoting.Messaging;

namespace MathExpr
{
    public class Token
    {
        public enum Type //TODO : Rename
        {
            PAROP,
            PARCLO,
            PLUS,
            MINUS,
            MULT,
            DIV,
            INT
        }

        private Type _toktype;
        private string _val;

        public Type TokType
        {
            get { return _toktype; }
        }
        
        public string Val
        {
            get { return _val; }
        }

        public Token(Type toktype, string val)
        {
            _toktype = toktype;
            _val = val;
        }

        public override string ToString()
        {
            return _val;
        }
    }
}