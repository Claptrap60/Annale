﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Runtime.Remoting.Messaging;

namespace MathExpr
{
    public class UnaryNode : INode
    {
        private bool _positive;
        private INode _val;

        public UnaryNode(bool positive)
        {
            _positive = positive;
            _val = null;
        }

        public void Build(Stack<INode> output)
        {
            if (output.Count == 0)
                throw new InvalidExpressionException();

            _val = output.Pop();
            _val.Build(output);
        }

        public void Print()
        {
            Console.Write("(");
            Console.Write(_positive ? '+' : '-');
            _val.Print();
            Console.Write(")");
        }
        
        public void PrintRevertPolish()
        {
            _val.PrintRevertPolish();
            Console.Write((_positive ? "+" : "-") + " ");
        }

        public int Eval()
        {
            int val = _val.Eval();
            return _positive ? val : -val;
        }
    }
}