﻿using System;
using System.Collections.Generic;
using System.Data;

namespace MathExpr
{
    public static class Parser
    {
        private static ValueNode GetInt(Token token)
        {
            return new ValueNode(Int32.Parse(token.Val));
        }

        private static UnaryNode GetUnary(Token token)
        {
            if (token.TokType == Token.Type.MINUS)
                return new UnaryNode(false);
            if (token.TokType == Token.Type.PLUS)
                return new UnaryNode(true);
            
            throw new InvalidExpressionException();   
        }

        private static BinaryNode GetBinary(Token token)
        {
            switch (token.TokType)
            {
            case Token.Type.PLUS:
                return new BinaryNode(BinaryNode.Operator.PLUS);
            case Token.Type.MINUS:
                return new BinaryNode(BinaryNode.Operator.MINUS);
            case Token.Type.MULT:
                return new BinaryNode(BinaryNode.Operator.MULT);
            case Token.Type.DIV:
                return new BinaryNode(BinaryNode.Operator.DIV);
            default:
                throw new InvalidExpressionException();
            }
        }

        private static bool IsPrior(Token op1, BinaryNode op2)
        {
            if (op1.TokType == Token.Type.PAROP)
                return false;
            
            return op2.Op < BinaryNode.Operator.MULT || op1.TokType >= Token.Type.MULT;
        }

        private static Stack<INode> ShuntingYard(List<Token> tokens)
        {
            Stack<INode> output = new Stack<INode>();
            Stack<UnaryNode> unary = new Stack<UnaryNode>();
            Stack<Token> operators = new Stack<Token>();

            for (int i = 0; i < tokens.Count; ++i)
            {
                Token token = tokens[i];
                if (token.TokType == Token.Type.INT)
                {
                    if (i > 0 && tokens[i - 1].TokType == Token.Type.INT)
                        throw new InvalidExpressionException();
                    
                    output.Push(GetInt(token));

                    while (unary.Count != 0 && unary.Peek() != null)
                        output.Push(unary.Pop());
                }
                else if (token.TokType == Token.Type.PAROP)
                {
                    operators.Push(token);
                    unary.Push(null);
                }


                else if (token.TokType == Token.Type.PARCLO)
                {
                    for (Token op = operators.Pop(); op.TokType != Token.Type.PAROP; op = operators.Pop())
                        output.Push(GetBinary(op));
                    unary.Pop();
                    while (unary.Count != 0 && unary.Peek() != null)
                        output.Push(unary.Pop());
                }

                else if (i == 0 || (tokens[i - 1].TokType != Token.Type.INT
                                    && tokens[i - 1].TokType != Token.Type.PARCLO))
                    unary.Push(GetUnary(token));
                    
                else
                {
                    while (operators.Count != 0 && IsPrior(operators.Peek(), GetBinary(token)))
                        output.Push(GetBinary(operators.Pop()));
                    
                    operators.Push(token);
                }
            }
            
            while (operators.Count != 0)
                output.Push(GetBinary(operators.Pop()));

            return output;
        }
        
        public static INode Parse(string expr)
        {
            List<Token> tokens = Lexer.Lex(expr);
            foreach (var token in tokens)
            {
                Console.Write(token);
            }

            Stack<INode> output = ShuntingYard(tokens);

            INode ast = output.Pop();
            ast.Build(output);

            return ast;
        }
    }
}