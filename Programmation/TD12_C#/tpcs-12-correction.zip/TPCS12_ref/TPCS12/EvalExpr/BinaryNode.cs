﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace MathExpr
{
    public class BinaryNode : INode
    {
        public enum Operator
        {
            PLUS,
            MINUS,
            MULT,
            DIV
        };

        private Operator _op;
        private INode _left;
        private INode _right;

        public Operator Op
        {
            get { return _op; }
        }

        public BinaryNode(Operator op)
        {
            _op = op;
            _left = null;
            _right = null;
        }

        public void Build(Stack<INode> output)
        {
            if (output.Count == 0)
                throw new InvalidExpressionException();

            _right = output.Pop();
            _right.Build(output);
            
            if (output.Count == 0)
                throw new InvalidExpressionException();

            _left = output.Pop();
            _left.Build(output);
        }

        private string GetOpStr()
        {
            switch (_op)
            {
            case Operator.PLUS:
                return "+";
            case Operator.MINUS:
                return "-";
            case Operator.MULT:
                return "*";
            case Operator.DIV:
                return "/";
            default:
                throw new InvalidDataException("Operator does not exists.");
            }
        }

        public void Print()
        {
            Console.Write("(");
            _left.Print();
            Console.Write(GetOpStr());
            _right.Print();
            Console.Write(")");
        }

        public void PrintRevertPolish()
        {
            _left.PrintRevertPolish();
            _right.PrintRevertPolish();
            Console.Write(GetOpStr() + " ");
        }
        
        public int Eval()
        {
            switch (_op)
            {
            case Operator.PLUS:
                return _left.Eval() + _right.Eval();
            case Operator.MINUS:
                return _left.Eval() - _right.Eval();
            case Operator.MULT:
                return _left.Eval() * _right.Eval();
            case Operator.DIV:
                return _left.Eval() / _right.Eval();
            default:
                throw new InvalidDataException("Operator does not exists.");
            }
        }
    }
}