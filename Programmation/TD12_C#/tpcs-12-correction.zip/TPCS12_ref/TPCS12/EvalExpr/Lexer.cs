﻿using System.Collections.Generic;
using System.Data;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MathExpr
{
    public static class Lexer
    {

        private static void SkipSpaces(ref int pos, string expr)
        {
            while (pos < expr.Length && expr[pos] == ' ')
                pos++;
        }

        private static bool IsDigit(char c)
        {
            return c >= '0' && c <= '9';
        }

        private static int GetLenNum(int pos, string expr)
        {
            int len = 0;
            while (pos + len < expr.Length && IsDigit(expr[pos + len]))
                len += 1;
            return len;
        }
        
        private static Token Tokenize(ref int pos, string expr)
        {
            switch (expr[pos])
            {
            case '+':
                return new Token(Token.Type.PLUS, "+");
            case '-':
                return new Token(Token.Type.MINUS, "-");
            case '*':
                return new Token(Token.Type.MULT, "*");
            case '/':
                return new Token(Token.Type.DIV, "/");
            case '(':
                return new Token(Token.Type.PAROP, "(");
            case ')':
                return new Token(Token.Type.PARCLO, ")");
            }
            
            if (!IsDigit(expr[pos]))
                throw new InvalidExpressionException();

            int len = GetLenNum(pos, expr);

            Token token = new Token(Token.Type.INT, expr.Substring(pos, len));
            
            pos += len - 1; //TODO : Moche

            return token;
        }
        
        public static List<Token> Lex(string expr)
        {
            List<Token> tokens = new List<Token>();
            int pos = 0;
            
            SkipSpaces(ref pos, expr);
            while (pos < expr.Length)
            {
                tokens.Add(Tokenize(ref pos, expr));
                pos += 1;
                
                SkipSpaces(ref pos, expr);
            }

            return tokens;
        }
    }
}