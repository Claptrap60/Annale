﻿using System.Collections.Generic;

namespace MathExpr
{
    public interface INode
    {
        void Build(Stack<INode> output);
        void Print();
        void PrintRevertPolish();
        int Eval();
    }
}