﻿namespace TPCS12
{
    internal class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}