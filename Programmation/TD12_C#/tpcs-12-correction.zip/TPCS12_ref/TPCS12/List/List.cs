﻿using System;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace List
{
    public class List<T>
    {
        protected Node<T> head_;
        protected Node<T> tail_;

        public List()
        {
            head_ = null;
            tail_ = null;
        }

        public List(T data)
        {
            head_ = new Node<T>(data);
            tail_ = head_;
        }

        public void print()
        {
            Node<T> elt = head_;
            if (elt != null)
            {
                Console.Write(elt.Data);
                elt = elt.Next;
            }
            for (; elt != null; elt = elt.Next)
            {
                Console.Write(", " + elt.Data);
            }
            Console.WriteLine();
        }
 
        public T this[int i]
        {
            get
            {
                if (i < 0)
                    throw new ArgumentException();
                int count = 0;
                Node<T> elt = head_;
                for (; count < i && elt != null; elt = elt.Next)
                    ++count;
                if (i == count)
                    return elt.Data;
                else
                    throw new InvalidDataException();
            }
            set
            {
                if (i < 0)
                    throw new ArgumentException();
                int count = 0;
                Node<T> elt = head_;
                for (; count < i && elt != null; elt = elt.Next)
                    ++count;
                if (i == count)
                    elt.Data = value;
                else
                    throw new InvalidDataException();
            }
        }

        public void insert(int i, T value)
        {
            if (i < 0)
                throw new ArgumentException();
            int count = 0;
            Node<T> elt = head_;
            for (; count < i && elt != null; elt = elt.Next)
                ++count;
            if (i == count)
            {
                Node<T> temp = new Node<T>(value);
                if (tail_ == null)
                {
                    tail_ = temp;
                    head_ = temp;
                }
                else if (elt.Prev == null)
                {
                    temp.Next = head_;
                    if (temp.Next != null)
                        temp.Next.Prev = temp;
                    head_ = temp;
                }
                else
                {
                    temp.Next = elt;
                    temp.Prev = elt.Prev;
                    elt.Prev = temp;
                    temp.Prev.Next = temp;
                }
            }
            else
               throw new InvalidDataException();
        }

        public void delete(int i)
        {
            if (i < 0)
                throw new ArgumentException();
            int count = 0;
            Node<T> elt = head_;
            for (; count < i && elt != null; elt = elt.Next)
                ++count;
            if (i == count && elt != null)
            {
                if (head_ == tail_)
                {
                    tail_ = null;
                    head_ = null;
                }
                else if (elt.Next == null)
                {
                    tail_ = elt.Prev;
                    tail_.Next = null;
                }
                else if (elt.Prev == null)
                {
                    head_ = elt.Next;
                    head_.Prev = null;
                }
                else
                {
                    elt.Prev.Next = elt.Next;
                    elt.Next.Prev = elt.Prev;
                }
            }
            else
               throw new InvalidDataException();
        }
    }
}