﻿using System;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace List
{
    public class Stack<T> : List<T>
    {
        public Stack()
            : base()
        {}
        
        public Stack(T elt)
            : base(elt)
        {}
        
        public T front()
        {
            if (head_ != null)
                return head_.Data;
            else
                throw new InvalidDataException();
        }
        
        public void popFront()
        {
            if (head_ == null)
                return;
            if (head_ == tail_)
            {
                head_ = null;
                tail_ = null;
            }
            else
            {
                head_ = head_.Next;
                head_.Prev = null;
            }
        }
        
        public void pushFront(T elt)
        {
            Node<T> temp = new Node<T>(elt);
            if (head_ == null)
            {
                head_ = temp;
                tail_ = temp;
            }
            else
            {
                head_.Prev = temp;
                temp.Next = head_;
                head_ = temp;
            }
        }
    }
}