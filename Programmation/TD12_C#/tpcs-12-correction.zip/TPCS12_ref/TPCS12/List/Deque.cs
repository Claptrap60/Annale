﻿using System;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace List
{
    public class Dequeue<T> : List<T>
    {
        public Dequeue()
            : base()
        {}
        
        public Dequeue(T elt)
            : base(elt)
        {}
        
        public T front()
        {
            if (head_ != null)
                return head_.Data;
            else
                throw new InvalidDataException();
        }
        
        public T back()
        {
            if (tail_ != null)
                return tail_.Data;
            else
                throw new InvalidDataException();
        }
        
        public virtual void popBack()
        {
            if (tail_ == null)
                return;
            if (head_ == tail_)
            {
                head_ = null;
                tail_ = null;
            }
            else
            {
                tail_ = tail_.Prev;
                tail_.Next = null;
            }
        }
        
        public void popFront()
        {
            if (head_ == null)
                return;
            if (head_ == tail_)
            {
                head_ = null;
                tail_ = null;
            }
            else
            {
                head_ = head_.Next;
                head_.Prev = null;
            }
        }

        public void pushFront(T elt)
        {
            Node<T> temp = new Node<T>(elt);
            if (head_ == null)
            {
                head_ = temp;
                tail_ = temp;
            }
            else
            {
                head_.Prev = temp;
                temp.Next = head_;
                head_ = temp;
            }
        }
        
        public void pushBack(T elt)
        {
            Node<T> temp = new Node<T>(elt);
            if (head_ == null)
            {
                head_ = temp;
                tail_ = temp;
            }
            else
            {
                tail_.Next = temp;
                temp.Prev = tail_;
                tail_ = temp;
            }
        }
    }
}