﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;

namespace TinyBistro
{
    public class BigNum
    {
        private List<int> digits;

    }
}
