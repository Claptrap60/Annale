﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;

namespace TinyBistro
{
    public class BigNum
    {
        private List<int> digits;

        public BigNum(string number)
        {
            digits = new List<int>();
            foreach (char c in number)
            {
                if (c < '0' || c > '9')
                    throw new ArgumentException();
                AddDigit(c - '0');
            }

            for (int i = digits.Count - 1; i >= 0 && digits[i] == 0; i--)
                digits.RemoveAt(i);
        }

        public int GetNumDigits()
        {
            return digits.Count;
        }

        public void AddDigit(int digit)
        {
            digits.Add(digit);
        }

        public int GetDigit(int position)
        {
            if (position < 0 || position >= GetNumDigits())
                throw new OverflowException();
            return digits[position];
        }

        public void SetDigit(int digit, int position)
        {
            if (position < 0)
                throw new OverflowException();
            while (position >= GetNumDigits())
                AddDigit(0);
            digits[position] = digit;
        }

        public void Print()
        {
            if (digits.Count == 0)
                Console.WriteLine("0");
            else
            {
                for (int i = digits.Count - 1; i >= 0; i--)
                    Console.Write(digits[i].ToString());
                Console.WriteLine();
            }
        }

        public static bool operator <(BigNum a, BigNum b) 
        {
            if (a.GetNumDigits() != b.GetNumDigits())
                return a.GetNumDigits() < b.GetNumDigits();
            for (int i = 0; i < a.GetNumDigits(); i++)
                if (a.GetDigit(i) < b.GetDigit(i))
                    return true;
            return false;
        }
        
        public static bool operator >(BigNum a, BigNum b) 
        {
            if (a.GetNumDigits() != b.GetNumDigits())
                return a.GetNumDigits() > b.GetNumDigits();
            for (int i = 0; i < a.GetNumDigits(); i++)
                if (a.GetDigit(i) > b.GetDigit(i))
                    return true;
            return false;
        }
        
        public static bool operator ==(BigNum a, BigNum b) 
        {
            if (a.GetNumDigits() != b.GetNumDigits())
                return false;
            for (int i = 0; i < a.GetNumDigits(); i++)
                if (a.GetDigit(i) != b.GetDigit(i))
                    return false;
            return true;
        }
        
        public static bool operator !=(BigNum a, BigNum b)
        {
            return !(a == b);
        }
        
        public static BigNum operator +(BigNum a, BigNum b)
        {
            BigNum res = new BigNum("");
            int carry = 0;
            int lenA = a.GetNumDigits();
            int lenB = b.GetNumDigits();
            for (int i = 0; i < lenB || i < lenA; i++)
            {
                int tmp = carry;
                if (i < lenB)
                    tmp += b.GetDigit(i);
                if (i < lenA)
                    tmp += a.GetDigit(i);
                res.AddDigit(tmp % 10);
                carry = tmp / 10;
            }
            if (carry > 0)
                res.AddDigit(carry);
            return res;
        }
        
        public static BigNum operator -(BigNum a, BigNum b)
        {
            BigNum res = new BigNum("");
            int carry = 0;
            int lenA = a.GetNumDigits();
            int lenB = b.GetNumDigits();

            for (int i = 0; i < lenA; i++)
            {
                int tmp = a.GetDigit(i) - carry;
                if (i < lenB)
                    tmp -= b.GetDigit(i);
                carry = tmp < 0 ? 1 : 0;
                if (carry != 0)
                    tmp += 10;
                res.AddDigit(tmp);
            }
            
            return res;
        }
        public static BigNum operator *(BigNum a, BigNum b)
        { BigNum result = new BigNum("");

            for (int i = 0; i < b.GetNumDigits(); i++)
            {
                int carry = b.GetDigit(i);
                int wh = 0;
                int last = 0;
                for (int j = 0; j < a.GetNumDigits(); j++)
                {
                    int old = i + j < result.GetNumDigits()?
                        result.GetDigit(i + j) : 0;
                    int num = a.GetDigit(j) * carry + wh + old;
                    wh = 0;
                    if (num >= 10)
                    {
                        wh = num / 10;
                        num = num % 10;
                    }

                    result.SetDigit(num, i + j);

                    last = j;
                }
                if (wh != 0)
                    result.SetDigit(wh, last + i + 1);
            }

            return result;
        }
       public static BigNum operator /(BigNum a, BigNum b)
        {
            if (b.GetNumDigits()== 0)
                throw new OverflowException("Error: division by 0.");

            BigNum result = new BigNum("");
            if (b > a)
                return result;

            BigNum carry = new BigNum("");
            int i = a.GetNumDigits();

            do
            {
                carry.digits.Insert(0, a.digits[--i]);

                while (carry > b || carry == b)
                {
                    while (carry.GetNumDigits()!= 0 && carry.GetDigit(carry.GetNumDigits() - 1) == 0)
                        carry.digits.Remove(0);
                    if (carry.GetNumDigits() != 0)
                    {
                        carry = carry - b;
                        if (result.GetNumDigits() <= i)
                            result.SetDigit(1, i);
                        else
                            result.SetDigit(result.GetDigit(i)+1, i);
                    }
                }
            } while (i > 0);

            return result;
        }
       
        public static BigNum operator %(BigNum a, BigNum b)
        {
            if (b.GetNumDigits()== 0)
                throw new OverflowException("Error: division by 0.");

            BigNum result = new BigNum("");
            if (b > a)
                return result;

            BigNum carry = new BigNum("");
            int i = a.GetNumDigits();

            do
            {
                carry.digits.Insert(0, a.digits[--i]);

                while (carry > b || carry == b)
                {
                    while (carry.GetNumDigits()!= 0 && carry.GetDigit(carry.GetNumDigits() - 1) == 0)
                        carry.digits.Remove(0);
                    if (carry.GetNumDigits() != 0)
                    {
                        carry = carry - b;
                        if (result.GetNumDigits() <= i)
                            result.SetDigit(1, i);
                        else
                            result.SetDigit(result.GetDigit(i)+1, i);
                    }
                }
            } while (i > 0);

            return carry;
        }
    }
}