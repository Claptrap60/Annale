﻿using System;
using System.IO;
using System.Net;

namespace TinyBistro
{
    public static class Parser
    {

        static string GetFileContent()
        {
            if (!File.Exists("operation.txt"))
                throw new InvalidOperationException("The file 'operation.txt' does not exist");
            string tmp = File.ReadAllText("operation.txt");
            string res = "";
            foreach (char c in tmp)
            {
                if (c == '\n')
                    break;
                res += c;
            }
            return res;
        }

        static bool IsDigit(char c)
        {
            return c >= '0' && c <= '9';
        }
        
        static bool IsOperator(char c)
        {
            return c == '+' || c == '-' || c == '/' || c == '*' || c == '%';
        }
        
        static string GetFirstNum(string content, ref int indexOperation)
        {
            int i = 0;
            for (; i < content.Length && content[i] == ' '; ++i)
                continue;
            string res = "";
            for (; i < content.Length && content[i] != ' '; i++)
            {
                if (IsDigit(content[i]))
                    res += content[i];
                else if (IsOperator(content[i]))
                {
                    indexOperation = i;
                    return res;
                }
                else
                    throw new InvalidOperationException("File contains non authoriwed characters");
            }
            indexOperation = i;
            return res;
        }

        static int GetRealIndex(string content, int index)
        {
            for (int i = index; i < content.Length; ++i)
                if (content[i] != ' ')
                    return i;
            throw new InvalidOperationException("File is missing an operator and an operand");
        }
        
        static string GetSecondNum(string content, int indexSecond)
        {
            int i = indexSecond;
            for (; i < content.Length && content[i] == ' '; ++i)
                continue;
            string res = "";
            if (content[i] == '\n'  || i == content.Length)
                throw new InvalidOperationException("File is missing an operator and an operand");
            for (; i < content.Length && content[i] != ' ' && content[i] != '\n'; i++)
            {
                if (IsDigit(content[i]))
                    res += content[i];
                else
                    throw new InvalidOperationException("File contains non authoriwed characters");
            }
            return res;
        }
        public static void Parse()
        {
            string content = GetFileContent();
            int indexOperation = 0;
            
            BigNum firstNum = new BigNum(GetFirstNum(content, ref indexOperation));
            
            indexOperation = GetRealIndex(content, indexOperation);
            
            BigNum secondNum = new BigNum(GetSecondNum(content, indexOperation + 1));

            BigNum result;
            switch (content[indexOperation])
            {
                    case '+':
                        result = firstNum + secondNum;
                        break;
                     
                    case  '-':
                        result = firstNum - secondNum;
                        break;
                    
                    case '*':
                        result = firstNum * secondNum;
                        break;
                     
                    case '/':
                        result = firstNum / secondNum;
                        break;
                        
                    case '%':
                        result = firstNum % secondNum;
                        break;
                        
                    default:
                        throw new InvalidOperationException("Operand not recognized");                
            }
            
            Console.Write("Result of the operation = ");
            result.Print();
        }
    }
}