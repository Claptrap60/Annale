﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace integral
{
    class Integral
    {
        public static double IntegralRectangleRule(double a, double b, Func<double, double> f)
        {
            return (b - a) * f(a);
        }

        public static double CompositeIntegralRectangleRule(double a, double b, double n, Func<double, double> f)
        {
            double res = 0;

            while (a + n <= b)
            {
                res += IntegralRectangleRule(a, a + n, f);
                a += n;
            }

            return res;
        }

        public static double CIRRErrorMargin(double a, double b, double n, Func<double, double> f, Func<double, double> F)
        {
            return F(b) - F(a) - CompositeIntegralRectangleRule(a, b, n, f);
        }

        public static double IntegralTrapezoidalRule(double a, double b, Func<double, double> f)
        {
            return (f(a) + f(b)) * (b - a) / 2;
        }

        public static double CompositeIntegralTrapezoidalRule(double a, double b, double n, Func<double, double> f)
        {
            double res = 0;

            while (a + n <= b)
            {
                res += IntegralTrapezoidalRule(a, a + n, f);
                a += n;
            }

            return res;
        }

        public static double CITRErrorMargin(double a, double b, double n, Func<double, double> f, Func<double, double> F)
        {
            return F(b) - F(a) - CompositeIntegralTrapezoidalRule(a, b, n, f);
        }

        public static double IntegralSimpsonRule(double a, double b, Func<double, double> f)
        {
            double factor = (b - a) / 6;
            double fm = f((a + b) / 2);

            return factor * (f(a) + 4 * fm + f(b));
        }

        public static double CompositeIntegralSimpsonRule(double a, double b, double n, Func<double, double> f)
        {
            // nb_intervals must be pair
            double nb_intervals = (b - a) / n;
            double x2j;
            double x2j_1;

            double firstSum = 0;
            double secondSum = 0;

            for (int i = 1; i <= nb_intervals / 2 - 1; ++i)
            {
                x2j = a + 2 * i * n;
                firstSum += f(x2j);
            }

            for (int i = 1; i <= nb_intervals / 2; ++i)
            {
                x2j_1 = a + (2 * i - 1) * n;
                secondSum += f(x2j_1);
            }

            return (n / 3) * (f(a) + 2 * firstSum + 4 * secondSum + f(b));
        }

        public static double CISRErrorMargin(double a, double b, double n, Func<double, double> f, Func<double, double> F)
        {
            return F(b) - F(a) - CompositeIntegralSimpsonRule(a, b, n, f);
        }
    }
}
