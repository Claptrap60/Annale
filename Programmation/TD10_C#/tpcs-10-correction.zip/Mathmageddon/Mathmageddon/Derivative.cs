﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace derivative
{
    class Derivative
    {
        public static double RateOfChange(double a, double h, Func<double, double> f)
        {
            if (h == 0)
                throw new DivideByZeroException("h cannot be null");

            double slope = (f(a + h) - f(a)) / h;
            return (int)(slope * 1000000) / 1000000;
        }

        public static List<double> GeneratePointsForPlot(double a, double b, double t, Func<double, double> f)
        {
            List<double> list = new List<double>();

            while (a < b)
            {
                if (a + t > b)
                    t = b - a;

                list.Add(RateOfChange(a, t, f));

                a += t;
            }

            return list;
        }

        public static List<List<double>> DisplayDerivatives()
        {
            List<List<double>> list = new List<List<double>>();
            Func<double, double> f = x => Math.Exp(x);
            Func<double, double> g = x => Math.Log(x);

            list.Add(GeneratePointsForPlot(0, 10, 1, f));
            list.Add(GeneratePointsForPlot(0, 10, 1, g));
            return list;
        }
    }
}
