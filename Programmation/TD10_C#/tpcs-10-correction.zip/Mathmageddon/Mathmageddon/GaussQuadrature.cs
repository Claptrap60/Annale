﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gauss
{
    class GaussQuadrature
    {
        public static double IntegralGaussQuadrature(double a, double b, uint n, Func<double, double> f)
        {
            double[,] coeffs = GaussCoefficients(n);
            Tuple<double[], double[]> p = GetGaussRootsAndweights(n, coeffs);
            return GaussIntegrate(f, n, a, b, p.Item1, p.Item2);
        }

        // calculate gauss coefficients
        static double[,] GaussCoefficients(uint n)
        {
            double[,] coeffs = new double[n + 1, n + 1];
            coeffs[0, 0] = 1;
            coeffs[1, 1] = 1;

            for (uint i = 2; i <= n; i++)
            {

                coeffs[i, 0] = -(i - 1) * coeffs[i - 2, 0] / i;

                for (uint j = 1; j <= n; j++)
                {
                    coeffs[i, j] = ((2 * i - 1) * coeffs[i - 1, j - 1]
                            - (i - 1) * coeffs[i - 2, j]) / i;
                }
            }
            return coeffs;
        }

        // evaluate gauss at x
        static double GaussEvaluation(uint n, double x, double[,] coeffs)
        {
            double s = coeffs[n, n];
            for (uint i = n; i > 0; i--)
                s = s * x + coeffs[n, i - 1];
            return s;
        }

        static double Difference(uint n, double x, double[,] coeffs)
        {
            return n * (x * GaussEvaluation(n, x, coeffs) - GaussEvaluation(n - 1, x, coeffs)) / (x * x - 1);
        }

        // calculate the roots and weights
        static Tuple<double[], double[]> GetGaussRootsAndweights(uint n, double[,] coeffs)
        {
            double[] roots = new double[n];
            double[] weights = new double[n];

            double x, x1;
            for (uint i = 1; i <= n; i++)
            {
                x = Math.Cos(Math.PI * (i - 0.25) / (n + 0.5));
                do
                {
                    x1 = x;
                    x -= GaussEvaluation(n, x, coeffs) / Difference(n, x, coeffs);
                } while (x != x1);

                roots[i - 1] = x;

                x1 = Difference(n, x, coeffs);
                weights[i - 1] = 2 / ((1 - x * x) * x1 * x1);
            }

            return new Tuple<double[], double[]>(roots, weights);
        }

        static double GaussIntegrate(Func<double, double> f, uint n, double a, double b, double[] roots, double[] weights)
        {
            double c1 = (b - a) / 2, c2 = (b + a) / 2, sum = 0;
            for (uint i = 0; i < n; i++)
                sum += weights[i] * f(c1 * roots[i] + c2);
            return c1 * sum;
        }
    }
}
