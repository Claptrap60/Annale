﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newton
{
    class NewtonQuadrature
    {
        private static Dictionary<int, Tuple<double, List<int>>> dico = new Dictionary<int, Tuple<double, List<int>>>();

        public static void InitDictionary()
        {
            if (dico.Keys.Count == 0)
            {
                dico.Add(1, new Tuple<double, List<int>>(1f / 2, new List<int> { 1, 1 }));
                dico.Add(2, new Tuple<double, List<int>>(1f / 6, new List<int> { 1, 4, 1 }));
                dico.Add(3, new Tuple<double, List<int>>(1f / 8, new List<int> { 1, 3, 3, 1 }));
                dico.Add(4, new Tuple<double, List<int>>(1f / 90, new List<int> { 7, 32, 12, 32, 7 }));
                dico.Add(5, new Tuple<double, List<int>>(1f / 288, new List<int> { 19, 75, 50, 50, 75, 19 }));
                dico.Add(6, new Tuple<double, List<int>>(1f / 840, new List<int> { 41, 216, 27, 272, 27, 216, 41 }));
                dico.Add(7, new Tuple<double, List<int>>(1f / 17280, new List<int> { 751, 3577, 1323, 2989, 2989, 1323, 3577, 751 }));
                dico.Add(8, new Tuple<double, List<int>>(1f / 28350, new List<int> { 989, 5888, -928, 10496, -4540, 10496, -928, 5888, 989 }));
                dico.Add(9, new Tuple<double, List<int>>(1f / 89600, new List<int> { 2857, 15741, 1080, 19344, 5778, 5778, 19344, 1080, 15741, 2857 }));
                dico.Add(10, new Tuple<double, List<int>>(1f / 598752, new List<int> { 16067, 106300, -48525, 272400, -260550, 427368, -260550, 272400, -48525, 106300, 16067 }));
            }
        }

        public static double IntegralNewtonQuadratureAt6(double a, double b, Func<double, double> f)
        {
            int n = 5;
            double h = (b - a) / n;
            List<int> w = new List<int> { 19, 75, 50, 50, 75, 19 };
            double constant = (5 / 288) * h; // (b - a) / 288

            double result = 0;

            for (int i = 0; i < n; ++i)
            {
                result += w[i] * f(a + i * h);
            }

            result *= constant;
            return result;
        }

        public static double IntegralNewtonQuadrature(double a, double b, int n, Func<double, double> f)
        {
            InitDictionary();

            double constant = (b - a) * dico[n].Item1;

            double h = (b - a) / n;
            List<int> w = dico[n].Item2;

            double result = 0;

            for (int i = 0; i <= n; ++i)
            {
                result += w[i] * f(a + i * h);
            }

            result *= constant;
            return result;
        }

        public static double CompositeIntegralNewtonQuadrature(double a, double b, double n, int d, Func<double, double> f)
        {
            double res = 0;

            while (a + n <= b)
            {
                res += IntegralNewtonQuadrature(a, a + n, d, f);
                a += n;
            }

            return res;
        }

        public static double CINQErrorMargin(double a, double b, double n, int d, Func<double, double> f, Func<double, double> F)
        {
            return F(b) - F(a) - CompositeIntegralNewtonQuadrature(a, b, n, d, f);
        }
    }
}
