﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace derivative
{
    class Derivative
    {
        public static double RateOfChange(double a, double h, Func<double, double> f)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public static List<double> GeneratePointsForPlot(double a, double b, double t, Func<double, double> f)
        {
            //FIXME
            throw new NotImplementedException();
        }
    }
}
