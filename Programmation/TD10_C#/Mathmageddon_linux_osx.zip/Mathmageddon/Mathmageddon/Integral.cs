﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace integral
{
    class Integral
    {
        public static double IntegralRectangleRule(double a, double b, Func<double, double> f)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public static double CompositeIntegralRectangleRule(double a, double b, double n, Func<double, double> f)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public static double CIRRErrorMargin(double a, double b, double n, Func<double, double> f, Func<double, double> F)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public static double IntegralTrapezoidalRule(double a, double b, Func<double, double> f)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public static double CompositeIntegralTrapezoidalRule(double a, double b, double n, Func<double, double> f)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public static double CITRErrorMargin(double a, double b, double n, Func<double, double> f, Func<double, double> F)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public static double IntegralSimpsonRule(double a, double b, Func<double, double> f)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public static double CompositeIntegralSimpsonRule(double a, double b, double n, Func<double, double> f)
        {
            //FIXME
            throw new NotImplementedException();
        }

        public static double CISRErrorMargin(double a, double b, double n, Func<double, double> f, Func<double, double> F)
        {
            //FIXME
            throw new NotImplementedException();
        }
    }
}
