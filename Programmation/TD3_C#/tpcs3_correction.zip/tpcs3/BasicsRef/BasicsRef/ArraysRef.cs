﻿namespace Basics
{
    public class ArraysRef
    {
        public static int Search(int[] arr, int e)
        {
            int pos = 0;
            foreach (int elt in arr)
            {
                if (elt == e)
                    return pos;
                pos++;
            }
            return -1;
        }

        public static int KingOfTheHill(int[] arr)
        {
            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i] < arr[i - 1])
                    return arr[i - 1];
            }
            return -1;
        }

        public static int[] CloneArray(int[] arr)
        {
            int[] clone = new int[arr.Length];
            for (int i = 0; i < arr.Length; i++)
                clone[i] = arr[i];
            return clone;
        }

        public static void BubbleSort(int[] arr)
        {
            bool sorted = false;
            while (!sorted)
            {
                sorted = true;
                for (int i = 1; i < arr.Length; i++)
                {
                    if (arr[i] < arr[i - 1])
                    {
                        int swap = arr[i];
                        arr[i] = arr[i - 1];
                        arr[i - 1] = swap;

                        sorted = false;
                    }
                }
            }
        }
    }
}