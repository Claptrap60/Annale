﻿using System;

namespace Basics
{
    public class Program
    {
        public static void Main(string[] args)
        {

        }
    }
}