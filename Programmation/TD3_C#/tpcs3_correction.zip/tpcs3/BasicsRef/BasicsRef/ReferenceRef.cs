﻿namespace Basics
{
    public class ReferenceRef
    {
        public static void Swap(ref int a, ref int b)
        {
            int temp = a;
            a = b;
            b = temp;
        }

        public static int Trunc(ref float f)
        {
            int res = (int) f;
            f = f % 1;
            return res;
        }

        public static void RotChar(ref char c, int n)
        {
            if (c >= '0' && c <= '9')
                c = (char) (c + n % 10 > '9' ? c + n % 10 - 10 : c + n % 10);
            else
            {
                n = n < 0 ? n % 26 + 26 : n % 26;
                if (c >= 'a' && c <= 'z')
                    c = (char) (c + n > 'z' ? c + n - 26 : c + n);
                else if (c >= 'A' && c <= 'Z')
                    c = (char) (c + n > 'Z' ? c + n - 26 : c + n);
            }
        }
    }
}