﻿using System;

namespace Takuzu
{
    public class TakuzuRef
    {
        private static void PrintRow(int[,] grid, int row)
        {
            int width = grid.GetLength(1);
            for (int i = 0; i < width; i++)
            {
                Console.Write("|");
                if (grid[row, i] == -1)
                    Console.Write(" ");
                else 
                    Console.Write(grid[row, i]);
            }
            Console.WriteLine("|");
        }

        private static void PrintColNumbers(int[,] grid)
        {
            int width = grid.GetLength(1);
            Console.Write("  ");
            for (int i = 0; i < width; i++)
            {
                Console.Write(" " + i.ToString());
            }
            Console.WriteLine(); 
        }
        
        public static void PrintGrid(int[,] grid)
        {
            PrintColNumbers(grid);
            int height = grid.GetLength(0);
            for (int i = 0; i < height; i++)
            {
                Console.Write(i.ToString() + " ");
                PrintRow(grid, i);
            }
        }
        
        public static bool IsRowValid(int[,] grid, int row)
        {
            int width = grid.GetLength(1);
            int[] values = {0, 0};
            int last = -1;
            int count = 0;

            for (int i = 0; i < width; i++)
            {
                int cell = grid[row, i];
                
                if (cell != last)
                {
                    last = cell;
                    count = 0;
                }
                
                if (cell == -1)
                    continue;

                values[cell]++;

                if (++count > 2)
                    return false;
            }

            return values[0] <= width / 2 && values[1] <= width / 2;
        }
        
        public static bool IsColumnValid(int[,] grid, int col)
        {
            
            int height = grid.GetLength(0);
            int[] values = {0, 0};
            int last = -1;
            int count = 0;

            for (int i = 0; i < height; i++)
            {
                int cell = grid[i, col];
                
                if (cell != last)
                {
                    last = cell;
                    count = 0;
                }
                
                if (cell == -1)
                    continue;

                values[cell]++;

                if (++count > 2)
                    return false;
            }

            return values[0] <= height / 2 && values[1] <= height / 2;
        }

        /* checks if row at pos a is different from all rows > a */
        private static bool IsRowDiffSup(int[,] grid, int a)
        {
            int width = grid.GetLength(1);
            int height = grid.GetLength(0);

            for (int j = 0; j < width; j++)
            {
                if (grid[a, j] == -1)
                    return true;
            }
            
            for (int i = a + 1; i < height; i++)
            {
                int j = 0;
                while (j < width)
                {
                    if (grid[i, j] == -1 || grid[i, j] != grid[a, j])
                        break;
                    j++;
                }
                if (j == width)
                    return false;
            }
            return true;
        }
         
        /* checks if col at pos a is different from all cols > a */
        private static bool IsColDiffSup(int[,] grid, int a)
        {
            int width = grid.GetLength(0);
            int height = grid.GetLength(1);

            for (int j = 0; j < height; j++)
            {
                if (grid[j, a] == -1)
                    return true;
            }
            
            for (int j = a + 1; j < width; j++)
            {
                int i = 0;
                while (i < height)
                {
                    if (grid[i, j] == -1 || grid[i, j] != grid[a, j])
                        break;
                    i++;
                }
                if (j == width)
                    return false;
            }
            return true;
        }
        
        public static bool IsGridValid(int[,] grid)
        {
            int width = grid.GetLength(1);
            int height = grid.GetLength(0);

            for (int i = 0; i < height; i++)
            {
                if (!IsRowValid(grid, i) || !IsRowDiffSup(grid, i))
                    return false;
            }
            for (int j = 0; j < width; j++)
            {
                if (!IsColumnValid(grid, j) || !IsColDiffSup(grid, j))
                    return false;
            }
            return true;
        }

        private static bool IsGridFinished(int[,] grid)
        {
            foreach (int elt in grid)
            {
                if (elt == -1)
                    return false;
            }
            return IsGridValid(grid);
        }

        public static bool PutCell(int[,] grid, int x, int y, int val)
        {
            if (val < -1 || val > 1
                || x < 0 || x >= grid.GetLength(1)
                || y < 0 || y >= grid.GetLength(0))
                return false;
            
            int prev = grid[y, x];
            
            grid[y, x] = val;
            
            bool isvalid = IsGridValid(grid);
            
            if (!isvalid)
                grid[y, x] = prev;
            
            return isvalid;

        }
        
        public static int[,] CloneGrid(int[,] grid)
        {
            int width = grid.GetLength(0);
            int height = grid.GetLength(1);
            
            int[,] clone = new int[width, height];

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                clone[i,j] = grid[i,j];

                }
            }
            return clone;
        }

        public static void Game(int[,] start)
        {
            int[,] grid = CloneGrid(start);

            while (!IsGridFinished(grid))
            {
                PrintGrid(grid);
                
                Console.Write("x : ");
                string strx;
                while ((strx = Console.ReadLine()) == "")
                    continue;
                
                Console.Write("y : ");
                string stry;
                while ((stry = Console.ReadLine()) == "")
                    continue;
                
                int x = Convert.ToInt32(strx);
                int y = Convert.ToInt32(stry);
                
                if (start[y, x] != -1)
                {
                    Console.WriteLine("Cette valeur ne peut etre changee.");
                    continue;
                }
                
                Console.Write("value : ");
                string strvalue;
                while ((strvalue = Console.ReadLine()) == "")
                    continue;
                int value = Convert.ToInt32(strvalue);
                
                if (!PutCell(grid, x, y, value))
                    Console.WriteLine("Valeur invalide.");
                
            }
            
            PrintGrid(grid);
            Console.WriteLine("Felicitation !");
        }
        
        private static bool AI_Rec(int[,] arr, int x, int y)
        {
            // Check if previous modification did respect takuzu's rules
            if (!IsGridValid(arr))
                return false;
            
            // avoiding x out of bound
            if (x >= arr.GetLength(0))
            {
                x = 0;
                y += 1;
            }
            
            // check if all grid has been filled,
            // if so, since it is valid, it is completed
            if (y >= arr.GetLength(1))
                return true;
            
            // checks if cell is empty
            if (arr[y,x] != -1)
                return AI_Rec(arr, x + 1, y);
            
            //test with 0
            arr[y,x] = 0;
            if (AI_Rec (arr, x + 1, y))
                return true;
            
            //test with 1
            arr[y,x] = 1;
            if (AI_Rec (arr, x + 1, y))
                return true;
            
            //neither 0 nor 1 is valid so a bad value has been set
            // previously
            arr[y,x] = -1;
            return false;
        }	
        
        public static void AI(int[,] game)
        {
            AI_Rec(game, 0, 0);
        }
    }
}