﻿using System;
using System.Data.Common;

namespace Takuzu 
{
    public static class Takuzu
    {
        public static void PrintGrid(int[,] grid)
        {
            //FIXME
        }

        public static bool IsRowValid(int[,] grid, int row)
        {
            //FIXME
            return false;
        }
        
        public static bool IsColumnValid(int[,] grid, int col)
        {
            //FIXME
            return false;
        }

        public static bool IsGridValid(int[,] grid)
        {
            //FIXME
            return false;
        }

        public static bool PutCell(int[,] grid, int x, int y, int val)
        {
            //FIXME
            return false;
        }
        
        public static void Game(int[,] start)
        {
            //FIXME
        }

        public static int[,] AI(int[,] grid)
        {
            //FIXME
            return null;
        }
    }
}