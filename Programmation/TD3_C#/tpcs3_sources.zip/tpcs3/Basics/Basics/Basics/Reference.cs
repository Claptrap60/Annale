﻿namespace Basics
{
    public class Reference
    {
        public static void Swap(ref int a, ref int b)
        {
            //FIXME
        }

        public static int Trunc(ref float f)
        {
            //FIXME
            return -1;
        }

        public static void RotChar(ref char c, int n)
        {
            //FIXME    
        }
    }
}