﻿namespace Basics
{
    public class Arrays
    {
        public static int Search(int[] arr, int e)
        {
            //FIXME
            return -1;
        }

        public static int KingOfTheHill(int[] arr)
        {
            //FIXME
            return -1;
        }

        public static int[] CloneArray(int[] arr)
        {
            //FIXME
            return null;
        }

        public static void BubbleSort(int[] arr)
        {
            //FIXME
        }
    }
}