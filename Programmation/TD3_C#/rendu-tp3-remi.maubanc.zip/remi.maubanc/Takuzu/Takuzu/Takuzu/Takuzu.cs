﻿using System;
using System.ComponentModel;
using System.Data.Common;
using System.Data.SqlTypes;
using System.Runtime.Remoting.Messaging;

namespace Takuzu 
{
    public static class Takuzu
    {
        private static string What_char(int[,] tab, int x, int y)
        {
            if (tab[x, y] == 0)
            {
                return "0";
            }
            if (tab[x, y] == 1)
            {
                return "1";
            }
            if (tab[x, y] == -1)
            {
                return " ";
            }
            else
            {
                return "E";
            }
        }
        
        public static void PrintGrid(int[,] grid)
        {
            int larg = grid.GetLength(1);
            int longu = grid.GetLength(0);
            string first_line = "   ";
            //F1rst l1n3
            for (int i = 0; i < larg; i++)
            {
                first_line += i + " ";
            }
            Console.WriteLine(first_line);
            //0th3r l1n3
            for (int j = 0; j < longu; j++)
            {
                Console.Write(j + " |");
                for (int i = 0; i < larg; i++)
                {
                    Console.Write(What_char(grid, j, i) + "|");
                }
                Console.WriteLine();
            }
        }

        private static bool no_more_39(int[,] tab)
        {
            return true;
        }

        private static int count_0_or_1(int[,] tab, int dim, int n0mb, int test)
        /*the variable 'tab' is the board
          the variable 'dim' is 
                        - dim = 0, if we test a row
                        - dim = 1, if we test a col
          the variable 'n0mb' is the number of col/row
          the variable 'test' is the value (1 or 0) counted*/
        {
            int exit = 0;
            int longu = tab.GetLength(dim);
            if (dim == 0)
            {
                for (int i = 0; i < longu; i++)
                {
                    if (tab[i, n0mb] == test)
                    {
                        exit++;
                    }
                }
            }
            else
            {
                for (int i = 0; i < longu; i++)
                {
                    if (tab[n0mb, i] == test)
                    {
                        exit++;
                    }
                }
            }
            return exit;
        }

        public static bool IsRowValid(int[,] grid, int row)
        {
            return (count_0_or_1(grid, 1, row, 0) == count_0_or_1(grid, 1, row, 1));
        }
        
        public static bool IsColumnValid(int[,] grid, int col)
        {
            return (count_0_or_1(grid, 0, col, 0) == count_0_or_1(grid, 0, col, 1));
        }

        private static bool Comp_Column(int[,] tab)
        {
            int longu = tab.GetLength(0);
            bool exit = true;
            for (int i = 0; i < longu - 1; i++)
            {
                for (int h = i + 1; h < longu; h++)
                {
                    for (int j = 0; j < longu; j++)
                    {
                        exit &= ((tab[i, j] == tab[h, j]) || (tab[i,j] != -1) || (tab[h,j] != -1));
                        if (!exit)
                            break;
                    }
                    if (exit)
                        return exit;
                    if ((i < longu - 2) && (!exit))
                        exit = true;
                }
            }
            return exit;
        }
        
        private static bool Comp_Raw(int[,] tab)
        {
            int longu = tab.GetLength(0);
            bool exit = true;
            for (int i = 0; i < longu - 1; i++)
            {
                for (int h = i + 1; h < longu; h++)
                {
                    for (int j = 0; j < longu; j++)
                    {
                        exit &= ((tab[i, j] == tab[h, j]) || (tab[i,j] != -1) || (tab[h,j] != -1));
                        if (!exit)
                            break;
                    }
                    if (exit)
                        return exit;
                    if ((i < longu - 2) && (!exit))
                        exit = true;
                }
            }
            return exit;
        }

        private static bool n0mb_by_line(int[,] grid)
        {
            int longu = grid.GetLength(0);
            int larg = grid.GetLength(1);
            //scann lines
            int c = 0;
            for (int i = 0; i < larg; i++)
            {
                for (int j = 0; j < longu; j++)
                {
                    int c01 = 1;
                    if (j == 0)
                    {
                        c = grid[i, j];

                    }
                    else
                    {
                        if (c == grid[i, j])
                        {
                            c01++;
                        }
                        else
                        {
                            c = grid[i, j];
                            c01 = 1;
                        }
                    }
                    if (c01 > 2)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        
        private static bool n0mb_by_colu(int[,] grid)
        {
            int longu = grid.GetLength(0);
            int larg = grid.GetLength(1);
            //scann columnes
            int c = 0;
            for (int i = 0; i < larg; i++)
            {
                for (int j = 0; j < longu; j++)
                {
                    int c01 = 1;
                    if (j == 0)
                    {
                        c = grid[j, i];

                    }
                    else
                    {
                        if (c == grid[j, i])
                        {
                            c01++;
                        }
                        else
                        {
                            c = grid[j, i];
                            c01 = 1;
                        }
                    }
                    if (c01 > 2)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public static bool IsGridValid(int[,] grid)
        {
            int lenght = grid.GetLength(1);
            int x = 0;
            bool exit2 = true;
            while (x < lenght)
            {
                exit2 &= IsRowValid(grid, x);
                x++;
            }
            if (!exit2)
            {
                return exit2;
            }
            while (x < lenght)
            {
                exit2 &= IsColumnValid(grid, x);
                x++;
            }
            if (!exit2)
            {
                return exit2;
            }
            if (Comp_Column(grid))
            {
                return false;
            }
            if (Comp_Raw(grid))
            {
                return false;
            }
            return true;
        }
        
        private static int[] CloneArray(int[] arr)
        {
            int length = arr.Length;
            int[] exit = new int[length];
            for (int i = 0; i < length; i++)
            {
                exit[i] = arr[i];
            }
            return exit;
        }

        public static bool PutCell(int[,] grid, int x, int y, int val)
        {
            int haut = grid.GetLength(0);
            int longu = grid.GetLength(1);
            if ((x < 0) || (x > haut))
                return false;
            if ((y < 0) || (y > longu))
                return false;
            if ((val < 0) && (val > 1))
                return false;
            int[,] test = grid;
            test[x, y] = val;
            if (IsGridValid(test))
            {
                grid = test;
                return true;
            }
            return false;
        }
        
        public static void Game(int[,] start)
        {
            PrintGrid(start);
            Console.WriteLine("Coord in x");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Coord in y");
            int y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Value to change");
            int val = Convert.ToInt32(Console.ReadLine());
            PutCell(start, x, y, val);
            PrintGrid(start);
            Game(start);
        }

        public static int[,] AI(int[,] grid)
        {
            //Flemme
            return null;
        }
    }
}