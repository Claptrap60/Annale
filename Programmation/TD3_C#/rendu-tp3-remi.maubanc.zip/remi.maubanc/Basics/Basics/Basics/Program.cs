﻿using System;
using System.Collections.Generic;

namespace Basics
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            int[] arr ={1, 2, 3, 4, 5};
            Console.Write(Arrays.CloneArray(arr));
            
        }
    }
}