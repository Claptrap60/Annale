﻿using System;
using System.Text;

namespace Basics
{
    public class Reference
    {
        public static void Swap(ref int a, ref int b)
        {
            int temp = b;
            b = a;
            a = temp;
        }

        public static int Trunc(ref float f)
        {
            int temp = (int) f;
            f = f - temp;
            return temp;
        }

        private static int What_type(int char_ascii) // Type of character :
        {
            if ((char_ascii >= 48) && (char_ascii <= 57)) // Numb3rs
            {
                return 0;
            }
            if ((char_ascii >= 65) && (char_ascii <= 90)) // Uppercase
            {
                return 1;
            }
            if ((char_ascii >= 97) && (char_ascii <= 122)) // Lowercase
            {
                return 2;
            }
            return -1; // Others
        }

        private static int Ajust_char(int char_ascii, int char_ascii_ori, int sign) // Ajuste the char in the intervals
        {
            if (What_type(char_ascii_ori) == 0) // If the char is a number
            {
                while ((char_ascii < 48) || (char_ascii > 57))
                {
                    char_ascii += (10 * sign * -1) ;
                }
            }
            if (What_type(char_ascii_ori) == 1) // If the char is an uppercase
            {
                while ((char_ascii < 65) || (char_ascii > 90))
                {
                    char_ascii += (26 * sign * -1) ;
                }
            }
            if (What_type(char_ascii_ori) == 2)
            {
                while ((char_ascii < 97) || (char_ascii > 122)) // If the char is a lowercase
                {
                    char_ascii += (26 * sign * -1) ;
                }
            }
            
            return char_ascii;
        }
        
        public static void RotChar(ref char c, int n)
        {
            int n_abs = Math.Abs(n); // absolute value of n into the 'for'
            int c_ascii = (int) c; // ASCII value of 'c' transformed
            int c_ascii2 = (int) c; // ASCII value of 'c' non-modified
            n = n / n_abs; // n is equal at 1 or -1
            for (int i = n_abs; i > 0; i--)
            {
                c_ascii += n; // c_ascii is incremente or decrement
            }
            c_ascii = Ajust_char(c_ascii, c_ascii2, n); // Ajuste the value of c_ascii
            c = (char) c_ascii; //int -> char
        }

    }
}