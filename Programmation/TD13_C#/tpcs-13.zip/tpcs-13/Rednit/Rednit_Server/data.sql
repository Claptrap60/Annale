INSERT INTO users
VALUES (DEFAULT, 'hack0', 'z', 'hacker', 'man', 42, 'Hack me if you can', DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT);
INSERT INTO users
VALUES (DEFAULT, 'hack1', '4D', 'hacker', 'man', 42, 'Hack me if you can', DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT);
INSERT INTO users
VALUES (DEFAULT, 'hack2', 'Lo1', 'hacker', 'man', 42, 'Hack me if you can', DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT);
INSERT INTO users
VALUES (DEFAULT, 'hack3', 'abc', 'hacker', 'man', 42, 'Hack me if you can', DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT);

