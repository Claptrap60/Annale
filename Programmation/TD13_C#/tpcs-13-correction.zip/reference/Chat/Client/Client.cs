﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Client
{
	public class Client
	{
		private readonly Socket _sock;

		public void Run()
		{
			new Thread(() =>
			{
				while (true) ReceiveData();
			}) {IsBackground = true}.Start();

			while (true) SendData();
		}

		public Client(IPAddress address, int port)
		{
			_sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			_sock.Connect(address, port);
		}

		public void ReceiveData()
		{
			var buffer = new byte[1024];
			var receivedSize = _sock.Receive(buffer, 1024, SocketFlags.None);
			var message = Encoding.ASCII.GetString(buffer);
			message = message.Substring(0, receivedSize);
			if (!string.IsNullOrEmpty(message))
				Console.WriteLine(message);
		}

		public void SendData()
		{
			var message = Console.ReadLine();
			var buffer = Encoding.ASCII.GetBytes(message);
			if (!string.IsNullOrEmpty(message))
				_sock.Send(buffer, message.Length, SocketFlags.None);
		}
	}
}