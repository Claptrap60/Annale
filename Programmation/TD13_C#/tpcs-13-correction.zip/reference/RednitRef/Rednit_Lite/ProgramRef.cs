﻿using System;
using System.Net.Sockets;
using System.Windows.Forms;

namespace Rednit_LiteRef
{
    /// <summary>
    /// The main class.
    /// </summary>
	internal static class ProgramRef
	{
        /// <summary>
        /// The function called at the start of the client.
        /// Initialize this client.
        /// Run the FormConnect.
        /// Catch and handle exceptions thrown by the two actions above.
        /// </summary>
        [STAThread]
		public static void Main()
		{
			try
			{
				DataRef.Initialize();
                Application.Run(DataRef.Forms["Connect"]);
                if (DataRef.Client != null)
                    DataRef.Client.Close();
            }
            catch (SocketException)
            {
                if (DataRef.Client != null)
                    DataRef.Client.Close();
                MessageBox.Show(@"Wether the server is down. Wether you did something you shouldn't have. Bye.",
                    @"The server is unreachable.", MessageBoxButtons.OK);
            }
			catch (Exception e)
			{
				if (DataRef.Client != null)
					DataRef.Client.Close();
                MessageBox.Show(e.ToString(), @"Error", MessageBoxButtons.OK);
			}
		}
	}
}