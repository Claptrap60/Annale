﻿using System.Drawing;
using System.IO;
using System.Drawing.Imaging;

namespace Rednit_LiteRef
{
    /// <summary>
    /// Class to convert Image to byte array and the reverse.
    /// </summary>
    public static class ConvertImageRef
    {
        /// <summary>
        /// Converts an Image object to an array of bytes.
        /// </summary>
        /// <param name="imageIn">The image to convert.</param>
        /// <returns></returns>
        public static byte[] ImageToByteArray(Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, ImageFormat.Gif);
            return ms.ToArray();
        }
        /// <summary>
        /// Converts an array of bytes to an Image object.
        /// </summary>
        /// <param name="byteArrayIn">The byte array to convert.</param>
        /// <returns></returns>
        public static Image ByteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }
    }
}
