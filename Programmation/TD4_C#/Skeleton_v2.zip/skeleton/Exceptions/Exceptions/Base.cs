﻿using System;

namespace Exceptions
{
    public static class Base
    {
        public static int Fibonacci(int n)
        {
            // TODO
            throw new NotImplementedException("Fix this quickly");
        }

        public static float DegToRad(float angle)
        {
            // TODO
            throw new NotImplementedException("Fix this quickly");
        }
        
        public static float RadToDeg(float angle)
        {
            // TODO
            throw new NotImplementedException("Fix this quickly");
        }
        
        public static float Pow(float n, int p)
        {
            // TODO
            throw new NotImplementedException("Fix this quickly");
        }
    }
}