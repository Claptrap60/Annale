﻿using System;

namespace Exceptions
{
    public class BaseRef
    {
        public static int Fibonacci(int n)
        {
            if (n < 0)
                throw new ArgumentException("N must be positive");
            int n1 = 0;
            int n2 = 1;
            while (n != 0)
            {
                n2 += n1;
                n--;
                n1 = n2 - n1;
            }
            return n1;
        }

        public static float DegToRad(float angle)
        {
            if (angle < -180f || angle > 180f)
                throw new ArgumentException("Angle must be included between -180 and 180 degrees");
            return angle * (float)Math.PI / 180;
        }
        
        public static float RadToDeg(float angle)
        {
            float pi = (float)Math.PI;
            if (angle < -pi || angle > pi)
                throw new ArgumentException("Angle must be included between -180 and 180 degrees");
            return angle * 180 / pi;
        }
        
        public static float Pow(float n, int p)
        {
            float multiplicator = p > 0 ? n : 1 / n;
            float res = 1;
            float prev = 0;
            while (p != 0)
            {
                prev = res;
                res = multiplicator * res;
                if (Double.IsInfinity(res))
                    throw new OverflowException("Power is so high it overflows");
                p = p > 0 ? p - 1 : p + 1;
            }
            return res;
        }
    }
}