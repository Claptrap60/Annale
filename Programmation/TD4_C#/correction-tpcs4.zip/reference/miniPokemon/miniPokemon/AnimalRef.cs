﻿using System;
using System.Collections.Generic;

namespace miniPokemon
{
    public class AnimalRef
    {
        public AnimalRef(string name)
        {
            this.name = name;
        }

        private string name;

        public string Name
        {
            get { return name; }
        }

        public virtual void WhoAmI()
        {
            Console.WriteLine("I am an animal !");
        }

        public virtual void Describe()
        {
            Console.WriteLine("My name is " + name + ".");
        }

        public virtual void Rename(string NewName)
        {
            this.name = NewName;
            Console.WriteLine("My new name is " + name + " !");
        }
    }
}
