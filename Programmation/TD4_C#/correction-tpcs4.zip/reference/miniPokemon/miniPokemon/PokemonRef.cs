﻿using System;
using System.Collections.Generic;

namespace miniPokemon
{
    public class PokemonRef : AnimalRef
    {
        public enum Poketype
        {
            POISON,
            FIRE,
            WATER,
            GRASS,
            ELECTRICK
        };

        public PokemonRef(string name, int life, int damage, Poketype poketype)
        : base(name)
        {
            this.poketype = poketype;
            this.life = life;
            this.damage = damage;
            isKO = false;
            level = 1;
        }

        private Poketype poketype;
        private int damage;
        private int level;
        private int life;
        private bool isKO;

        public bool IsKO
        {
            get { return isKO; }
        }

        public int Life
        {
            get { return life; }
        }

        public override void WhoAmI()
        {
            Console.WriteLine("I'm a Pokemon");
        }

        public override void Describe()
        {
            Console.WriteLine("My name is " + Name + " I'm a pokemon of type " + poketype + " and I'm level " + level);
        }
        
        public void LevelUp()
        {
            level++;
        }

        public int Attack()
        {
            Console.WriteLine(Name + " uses cut, it's super effective");
            return damage;
        }

        public void GetHurt(int damage)
        {
            life = life - damage;
            if (life <= 0)
            {
                isKO = true;
                life = 0;
            }
        }

        public void Heal(int life)
        {
            this.life = life;
            isKO = false;
        }
    }
}
