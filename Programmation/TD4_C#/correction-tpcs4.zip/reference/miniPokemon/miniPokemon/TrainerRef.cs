﻿using System;
using System.Collections.Generic;

namespace miniPokemon
{
    class TrainerRef : AnimalRef
    {
        public TrainerRef(string name, int age)
        : base(name)
        {
            this.age = age;
            listPokemon = new List<PokemonRef>();
        }

        private int age;

        public int Age
        {
            get { return age; }
        }
        private List<PokemonRef> listPokemon;

        public override void WhoAmI()
        {
            Console.WriteLine("I'm a pokemon Trainer !");
        }

        public int NumberOfPokemon()
        {
            return listPokemon.Count;
        }

        public override void Describe()
        {
            Console.WriteLine("My name is " + Name + " I'm " + age + " and I have " + NumberOfPokemon() + " Pokemon !");
        }

        public void Birthday()
        {
            age++;
        }

        public void MyPokemon()
        {
            Console.WriteLine("My Pokemon are :");
            foreach(PokemonRef pokemon in listPokemon)
            {
                Console.WriteLine(pokemon.Name);
            }
        }

        public void CatchAPokemon(PokemonRef pokemon)
        {
            listPokemon.Add(pokemon);
        }
    }
}
