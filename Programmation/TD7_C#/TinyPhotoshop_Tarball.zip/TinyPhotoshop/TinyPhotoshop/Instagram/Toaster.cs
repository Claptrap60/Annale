﻿using System;
using System.Drawing;

namespace TinyPhotoshop
{
    public class InstaToaster : InstaFilter
    {
        public InstaToaster() : base("Toaster")
        {
            
        }
        
        public override Bitmap Process(Bitmap image)
        {
			//FIXME
			throw new NotImplementedException();
		}
    }
}