﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace TinyPhotoshop
{
    public static class Steganography
    {

        public static Image EncryptImage(Bitmap img, Bitmap enc)
        {
			//FIXME
			throw new NotImplementedException();
		}

		public static Image DecryptImage(Bitmap img)
		{
			//FIXME
			throw new NotImplementedException();
		}

		public static Image EncryptText(Bitmap img, string text)
		{
			//FIXME
			throw new NotImplementedException();
		}

		public static string DecryptText(Bitmap img)
        {
			//FIXME
			throw new NotImplementedException();
		}
    }
}