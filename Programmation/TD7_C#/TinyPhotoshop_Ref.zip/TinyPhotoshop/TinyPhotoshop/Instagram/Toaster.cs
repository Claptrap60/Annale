﻿using System.Drawing;

namespace TinyPhotoshop
{
    public class InstaToaster : InstaFilter
    {
        public InstaToaster() : base("Toaster")
        {
            
        }
        
        public override Bitmap Process(Bitmap image)
        {
            //image = ColorTone(image, Color.FromArgb(50, 51, 0, 0));
            image = Vignette(image, Color.FromArgb(50, 255, 255, 255), Color.FromArgb(205, 193, 197));
            image = Vignette(image, Color.FromArgb(50, 255, 153, 102),Color.FromArgb(255, 0, 0, 0));
            return image;
        }
    }
}