﻿using System.Drawing;

namespace TinyPhotoshop
{
    public class InstaNashville : InstaFilter
    {
        public InstaNashville()
               : base("Nashville")
        {
        }

        public override Bitmap Process(Bitmap image)
        {
            throw new System.NotImplementedException();
        }
    }
}