﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace TinyPhotoshop
{
    public abstract class InstaFilter : Filter
    {
        public InstaFilter(string name) : base(name)
        {
        }

        //https://en.wikipedia.org/wiki/Vignetting
        private void PaintVignette(Graphics g, Rectangle bounds,
                                  Color color1, Color color2, float crop = 0.5f)
        {
            Rectangle ellipsebounds = bounds;
            ellipsebounds.Offset(-ellipsebounds.X, -ellipsebounds.Y);
            int x = ellipsebounds.Width - (int) Math.Round(crop * ellipsebounds.Width);
            int y = ellipsebounds.Height - (int) Math.Round(crop * ellipsebounds.Height);
            ellipsebounds.Inflate(x, y);

            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddEllipse(ellipsebounds);
                using (PathGradientBrush brush = new PathGradientBrush(path))
                {
                    brush.WrapMode = WrapMode.Tile;
                    brush.CenterPoint = new PointF(bounds.Width/2f, bounds.Height/2f);
                    brush.CenterColor = color1;
                    brush.SurroundColors = new Color[] {color2};
                    g.FillRectangle(brush, ellipsebounds);
                }
            }
        }

        public Bitmap Vignette(Bitmap b, Color c1, Color c2, float crop = 0.5f)
        {
            
            /*Color color1 = Color.FromArgb(0, 255, 255, 255);
            Color color2 = Color.FromArgb(255, 0, 0, 0);
            Bitmap final = new Bitmap(b);
            using (Graphics g = Graphics.FromImage(final))
            {
                PaintVignette(g, new Rectangle(0, 0, final.Width, final.Height), c1, c2, crop);
                return final;
            }*/

            return Vignette(b, c1.R, c1.G, c1.B);
        }
        
        public Bitmap Vignette(Bitmap image, int r, int g, int b)
        {
            float cr = 0, cg = 0, cb = 0, ca;
            int i = 0, j = 0,
                h = image.Height,
                w = image.Width,
                centerw = w / 2,
                centerh = h / 2,
                maxdist = dist(0, 0, centerw, centerh);

            
            maxdist = (int)(maxdist*0.6f);
            int radius = maxdist / 2;

            for (i = 0; i < w; i++)
            {
                for (j = 0; j < h; j++)
                {
                    Color temp = image.GetPixel(i, j);
                    cr = temp.R; cg = temp.G; cb = temp.B; ca = temp.A;
                    int distance = dist(i, j, centerw, centerh);
                    distance = (distance>radius)?distance-radius:0;

                    float ratio = ((distance / (float)(maxdist)));
                    cr = (1 - ratio) * cr + (ratio * r);
                    cg = (1 - ratio) * cg + (ratio * g);
                    cb = (1 - ratio) * cb + (ratio * b);

                    image.SetPixel(i, j, Color.FromArgb((int)clamp(ca, 0, 255), (int)clamp(cr, 0, 255),
                        (int)clamp(cg, 0, 255), (int)clamp(cb, 0, 255)));
                }
            }
            return image;
        }
        
        public static float clamp(float val, float min, float max)
        {
            return Math.Min(max, Math.Max(min, val));
        }

        int dist(int x1, int y1, int x2, int y2)
        {
            return (int) Math.Sqrt((Math.Abs(x1-x2)*Math.Abs(x1-x2) + Math.Abs(y1-y2)*Math.Abs(y1-y2)));
            //return approx_distance(Math.Abs(x1 - x2), Math.Abs(y1 - y2));
        }


        //https://msdn.microsoft.com/en-us/library/system.drawing.imaging.imageattributes(v=vs.110).aspx
        public Bitmap ColorTone(Image image, Color color)
        {

            float r = color.R / 255f;
            float g = color.G / 255f;
            float b = color.B / 255f;

            // Make the ColorMatrix.
            ColorMatrix cm = new ColorMatrix(new float[][]
            {
                new float[] {r, 0, 0, 0, 0},
                new float[] {0, g, 0, 0, 0},
                new float[] {0, 0, b, 0, 0},
                new float[] {0, 0, 0, 1, 0},
                new float[] {0, 0, 0, 0, 1}
            });
            ImageAttributes attributes = new ImageAttributes();
            attributes.SetColorMatrix(cm);

            // Draw the image onto the new bitmap while applying the new ColorMatrix.
            Point[] points =
            {
                new Point(0, 0),
                new Point(image.Width - 1, 0),
                new Point(0, image.Height - 1),
            };
            Rectangle rect = new Rectangle(0, 0, image.Width, image.Height);

            // Make the result bitmap.
            Bitmap bm = new Bitmap(image.Width, image.Height);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                gr.DrawImage(image, points, rect, GraphicsUnit.Pixel, attributes);
            }

            // Return the result.
            return bm;
        }


    }
}