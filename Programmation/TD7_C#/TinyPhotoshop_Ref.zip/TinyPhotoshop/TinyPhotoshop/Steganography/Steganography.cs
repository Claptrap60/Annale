﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace TinyPhotoshop
{
    public static class Steganography
    {
        private static byte LessSignificant(int b)
        {
            return Convert.ToByte(b & 15);
        }
      
        private static byte MostSignificant(int b)
        {
            return Convert.ToByte((b & (15 << 4)) >> 4);
        }

        private static byte[] GetBytes(string text, int length)
        {
            byte[] res = new byte[length];
            for (int i = 0; i < length - 2; ++i)
            {
                res[i] = MostSignificant(text[i / 2]);
                ++i;
                res[i] = LessSignificant(text[i / 2]);
            }
            return res;
        }
      
        public static Image EncryptText(Bitmap img, string text)
        {
            if (2 * text.Length >= 3 * img.Size.Height * img.Size.Width)
                throw new ArgumentException("Text too long to fill the image.");
            int k = 0;
            int max = text.Length * 2 + 2;
            byte[] buff = GetBytes(text, max);
            for (int i = 0; i < img.Height && k < max; ++i)
            {
                for (int j = 0; j < img.Width && k < max; ++j)
                {
                    Color c = img.GetPixel(j, i);
                    int red = 0;
                    int blue = 0;
                    int green = 0;
                    if (k < max)
                        red = ((c.R >> 4) << 4) + buff[k++];
                    if (k < max)
                        green = ((c.G >> 4) << 4) + buff[k++];
                    if (k < max)
                        blue = ((c.B >> 4) << 4) + buff[k++];
                    img.SetPixel(j, i, Color.FromArgb(red, green, blue));
                }
            }
            return img;
        }

        private static Color GetPixelOut(Bitmap img, int j, int i)
        {
            if (j < img.Width && i < img.Height)
                return img.GetPixel(j, i);
            return Color.FromArgb(0, 0, 0);
        }
        
        public static Image EncryptImage(Bitmap img, Bitmap enc)
        {
            if (enc.Width > img.Width || enc.Height > img.Height)
                throw new ArgumentException("Image width or weight is superior to the reference image");
            for (int i = 0; i < img.Height; ++i)
            {
                for (int j = 0; j < img.Width; ++j)
                {
                    int red = (MostSignificant(img.GetPixel(j, i).R) << 4) + MostSignificant(GetPixelOut(enc, j, i).R);
                    int green = (MostSignificant(img.GetPixel(j, i).G) << 4) + MostSignificant(GetPixelOut(enc, j, i).G);
                    int blue = (MostSignificant(img.GetPixel(j, i).B) << 4) + MostSignificant(GetPixelOut(enc, j, i).B);
                    img.SetPixel(j, i, Color.FromArgb(red, green, blue)); 
                }
            }
            return img;
        }
        
        public static string DecryptText(Bitmap img)
        {
            string buff = "";
            string res = "";
            int stop = 0;
            int max = 0;
            for (int i = 0; i < img.Height && stop < 2; ++i)
            {
                for (int j = 0; j < img.Width && stop < 2; ++j)
                {
                    Color c = img.GetPixel(j, i);
                    int red = LessSignificant(c.R);
                    if (red == 0 || stop >= 2)
                        ++stop;
                    else
                        stop = 0;
                    buff += red;
                    int green = LessSignificant(c.G);
                    if (green == 0 || stop >= 2)
                        ++stop;
                    else
                        stop = 0;
                    buff += green;
                    int blue = LessSignificant(c.B);
                    if (blue == 0 || stop >= 2)
                        ++stop;
                    else
                        stop = 0;
                    buff += blue;
                    max += 3;
                }
            }
            for (int i = 0; i < max; ++i)
            {
                char c = Convert.ToChar(buff[i++] - '0' << 4);
                if (i < max)
                    c += Convert.ToChar(buff[i] - '0');
                res += c;
            }
            return res;
        }
        
        public static Image DecryptImage(Bitmap img)
        {
            Bitmap res = new Bitmap(img.Width, img.Height);
            for (int i = 0; i < img.Height; ++i)
            {
                for (int j = 0; j < img.Width; ++j)
                {
                    int red = (LessSignificant(img.GetPixel(j, i).R) << 4);
                    int green = (LessSignificant(img.GetPixel(j, i).G) << 4);
                    int blue = (LessSignificant(img.GetPixel(j, i).B) << 4);
                    res.SetPixel(j, i, Color.FromArgb(red, green, blue)); 
                }
            }
            return res;
        }
    }
}