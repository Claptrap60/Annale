﻿using System;
using System.Drawing;

namespace TinyPhotoshop
{
    public static class Basics
    {
        public static Color Grey(Color color)
        {
            int grey = (color.R + color.G + color.B) / 3;
            return Color.FromArgb(grey, grey, grey);
        }

        public static Color Binarize(Color color)
        {
            int average = ((color.R + color.G + color.B) / 3) < 128 ? 0 : 255;
            return Color.FromArgb(average, average, average);
        }
        
        public static Color BinarizeColor(Color color)
        {
            return Color.FromArgb(color.R < 128 ? 0 : 255, color.G < 128 ? 0 : 255, color.B < 128 ? 0 : 255);
        }
        
        public static Color Negative(Color color)
        {
            return Color.FromArgb(255 - color.R, 255 - color.G, 255 - color.B);
        }
        
        public static Color Tinter(Color color, Color tint, int factor)
        {
            return Color.FromArgb((color.R * (100 - factor) / 100 + tint.R * factor / 100) / 2,
                                  (color.G * (100 - factor) / 100 + tint.G * factor / 100) / 2,
                                  (color.B * (100 - factor) / 100 + tint.B * factor / 100) / 2);
        }

        public static Image Apply(Bitmap img, Func<Color, Color> func)
        {
            for (int i = 0; i < img.Height; ++i)
            {
                for (int j = 0; j < img.Width; ++j)
                {
                    img.SetPixel(j, i, func(img.GetPixel(j, i)));
                }
            }
            return img;
        }
    }
}