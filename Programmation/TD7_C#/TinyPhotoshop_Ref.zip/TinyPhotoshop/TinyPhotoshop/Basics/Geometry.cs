﻿using System;
using System.Drawing;
using System.Net.Mime;
using System.Runtime.InteropServices;
using System.Security.Policy;


namespace TinyPhotoshop
{
    public static class Geometry
    {
        private static Color GetRefPixel(Bitmap img, float x, float y)
        {
            if (x > (int) x && y > (int) y)
            {
                int pos = (y - ((int) y) >= 0.5) ? 1 : -1;
                int pos2 = ((x - ((int) x) < 0.5)) ? -1 : 1;
                int R = (HandlerGetPixel(img, (int) x, (int) y).R +
                         HandlerGetPixel(img, (int) x + pos2, (int) y).R +
                         HandlerGetPixel(img, (int) x, (int) y + pos).R +
                         HandlerGetPixel(img, (int) x + pos2, (int) y + pos).R) / 4;
                int G = (HandlerGetPixel(img, (int) x, (int) y).G +
                         HandlerGetPixel(img, (int) x + pos2, (int) y).G +
                         HandlerGetPixel(img, (int) x, (int) y + pos).G +
                         HandlerGetPixel(img, (int) x + pos2, (int) y + pos).G) / 4;
                int B = (HandlerGetPixel(img, (int) x, (int) y).B +
                         HandlerGetPixel(img, (int) x + pos2, (int) y).B +
                         HandlerGetPixel(img, (int) x, (int) y + pos).B +
                         HandlerGetPixel(img, (int) x + pos2, (int) y + pos).B) / 4;
                return Color.FromArgb(R, G, B);
            }
            else if (x > (int) x)
            {
                int pos = (x - ((int) x) >= 0.5) ? 1 : -1;
                int R = (HandlerGetPixel(img, (int) x, (int) y).R +
                         HandlerGetPixel(img, (int) x + pos, (int) y).R) / 2;
                int G = (HandlerGetPixel(img, (int) x, (int) y).G +
                         HandlerGetPixel(img, (int) x + pos, (int) y).G) / 2;
                int B = (HandlerGetPixel(img, (int) x, (int) y).B +
                         HandlerGetPixel(img, (int) x + pos, (int) y).B) / 2;
                return Color.FromArgb(R, G, B);
            }
            else
            {
                int pos = (y - ((int) y) >= 0.5) ? 1 : -1;
                int R = (HandlerGetPixel(img, (int) x, (int) y).R +
                         HandlerGetPixel(img, (int) x, (int) y + pos).R) / 2;
                int G = (HandlerGetPixel(img, (int) x, (int) y).G +
                         HandlerGetPixel(img, (int) x, (int) y + pos).G) / 2;
                int B = (HandlerGetPixel(img, (int) x, (int) y).B +
                         HandlerGetPixel(img, (int) x, (int) y + pos).B) / 2;
                return Color.FromArgb(R, G, B);
            }
        }

        private static Color HandlerGetPixel(Bitmap img, int x, int y)
        {
            return Convolution.IsValid(x, y, img.Size) ? img.GetPixel(x, y) : Color.White;
        }

        public static Image Resize(Bitmap img, int x, int y)
        {
            Bitmap res = new Bitmap(x, y);
            int w = img.Width;
            int h = img.Height;
            float ratioX = (float) w / x;
            float ratioY = (float) h / y;
            for (int i = 0; i < x; ++i)
            {
                for (int j = 0; j < y; ++j)
                {
                    Color pixel = ((float) i * ratioX == (int) (i * ratioX) && (float) j * ratioY == (int) (j * ratioY))
                        ? HandlerGetPixel(img, (int) (i * ratioX), (int) (j * ratioY))
                        : GetRefPixel(img, (i * ratioX), (j * ratioY));
                    res.SetPixel(i, j, pixel);
                }
            }
            return res;
        }

        public static Image Shift(Bitmap img, int x, int y)
        {
            int w = img.Width;
            int h = img.Height;
            if (x >= 0)
                x %= w;
            else
                x = w - ((-x) % w);
            if (y >= 0)
                y %= h;
            else
                y = h - ((-y) % h);
            Bitmap res = new Bitmap(img);
            for (int i = 0; i < h; ++i)
            {
                for (int j = 0; j < w; ++j)
                {
                    res.SetPixel((j + x) % w, (i + y) % h, img.GetPixel(j, i));
                }
            }
            return res;
        }

        public static Image SymmetryHorizontal(Bitmap img)
        {
            int w = img.Width;
            int h = img.Height;
            for (int y = 0; y < h / 2; ++y)
            {
                for (int x = 0; x < w; ++x)
                {
                    Color tmp = img.GetPixel(x, y);
                    img.SetPixel(x, y, img.GetPixel(x, h - y - 1));
                    img.SetPixel(x, h - y - 1, tmp);
                }
            }
            return img;
        }

        public static Image SymmetryVertical(Bitmap img)
        {
            int w = img.Width;
            int h = img.Height;
            for (int y = 0; y < h; ++y)
            {
                for (int x = 0; x < w / 2; ++x)
                {
                    Color tmp = img.GetPixel(x, y);
                    img.SetPixel(x, y, img.GetPixel(w - x - 1, y));
                    img.SetPixel(w - x - 1, y, tmp);
                }
            }
            return img;
        }

        public static Image SymmetryPoint(Bitmap img, int x, int y)
        {
            Bitmap res = new Bitmap(img.Width, img.Height);
            int w = img.Width;
            int h = img.Height;
            for (int i = 0; i < w; ++i)
                for (int j = 0; j < h; ++j)
                    res.SetPixel(((2 * x - i) + w) % w, ((2 * y - j) + h) % h, img.GetPixel(i, j));
            return res;
        }

        public static Image RotationLeft(Bitmap img)
        {
            int w = img.Width;
            int h = img.Height;
            Bitmap res = new Bitmap(h, w);
            for (int y = 0; y < w; ++y)
            {
                for (int x = 0; x < h; ++x)
                    res.SetPixel(x, y, img.GetPixel(w - y - 1, x));
            }
            return res;
        }

        public static Image RotationRight(Bitmap img)
        {
            int w = img.Width;
            int h = img.Height;
            Bitmap res = new Bitmap(h, w);
            for (int y = 0; y < w; ++y)
            {
                for (int x = 0; x < h; ++x)
                    res.SetPixel(x, y, img.GetPixel(y, h - x - 1));
            }
            return res;
        }
    }
}