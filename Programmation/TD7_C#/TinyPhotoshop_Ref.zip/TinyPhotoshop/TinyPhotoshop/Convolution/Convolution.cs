﻿using System.Drawing;

namespace TinyPhotoshop
{
    public static class Convolution
    {
      
        public static float[,] Gauss = {
            {1/9f, 2/9f, 1/9f},
            {2/9f, 4/9f, 2/9f},
            {1/9f, 2/9f, 1/9f}
        };
        
        public static float[,] Sharpen = {
            { 0f, -1f,  0f},
            {-1f,  5f, -1f},
            { 0f, -1f,  0f}
        };
        
        public static float[,] Blur = {
            {1/9f, 1/9f, 1/9f},
            {1/9f, 1/9f, 1/9f},
            {1/9f, 1/9f, 1/9f}
        };
        
        public static float[,] EdgeEnhance = {
            { 0f, 0f, 0f},
            {-1f, 1f, 0f},
            { 0f, 0f, 0f}
        };
        
        public static float[,] EdgeDetect = {
            {0f,  1f, 0f},
            {1f, -4f, 1f},
            {0f,  1f, 0f}
        };
        
        public static float[,] Emboss = {
            {-2f, -1f, 0f},
            {-1f,  1f, 1f},
            { 0f,  1f, 2f}
        };
        
        private static int Clamp(float c)
        {
            return c > 255 ? 255 : c < 0 ? 0 : (int)c;
        }

        public static bool IsValid(int x, int y, Size size)
        {
            return x >= 0 && x < size.Width && y >= 0 && y < size.Height;
        }
        
        public static Image Convolute(Bitmap img, float[,] mask)
        {
            int offset = mask.GetLength(0) / 2;
            Bitmap res = new Bitmap(img);
            for (int y = 0; y < img.Size.Height; ++y)
            {
                for (int x = 0; x < img.Size.Width; ++x)
                {
                    float red = 0;
                    float green = 0;
                    float blue = 0;
                    for (int dy = -offset; dy <= offset; ++dy)
                    {
                        for (int dx = -offset; dx <= offset; ++dx)
                        {
                            if (IsValid(x + dx, y + dy, img.Size))
                            {
                                Color c = img.GetPixel(x + dx, y + dy);
                                float coef = mask[dy + offset, dx + offset];
                                red += c.R * coef;
                                green += c.G * coef;
                                blue += c.B * coef;
                            }
                        }
                    }
                    res.SetPixel(x, y, Color.FromArgb(Clamp(red), Clamp(green), Clamp(blue)));
                }
            }
            return res;
        }
    }
}