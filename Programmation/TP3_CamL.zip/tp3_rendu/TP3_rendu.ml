
(* Exercice 1.1.1 Reverse *)

let reverse n =
  if n < 0 then
    invalid_arg "n doit etre positif ou nul"
  else
    let rec reverse_rec n l =
      match n with
	|0 -> l
	|_ -> reverse_rec (n/10) (l*10+n mod 10)
    in
    reverse_rec n 0;;

(* Exercice 1.1.2 Prime *)

let prime n =
  if n <=2 then
    invalid_arg "n doit etre superieur a 2"
  else
    let rec prime_rec c n =
      if n <> c then
	if n mod c <> 0 then
	  prime_rec (c+1) n
	else
	  false
      else
	true
    in
    prime_rec 2 n;;
     
(* Exercice 1.2.1 Length *)

let length l =
  let rec length_rec l c =
    match l with
      |[] -> c
      |e1::l1 -> length_rec (l1) (c+1)
  in
  length_rec l 0;;

(* Exercice 1.2.2 count* *)

let count v l =
  let rec count_rec v l c =
    match l with
      |[] -> c
      |e1::l1 -> if e1 = v then
	  count_rec (v) (l1) (c+1)
	    else
	  count_rec v l1 c
  in
  count_rec v l 0;;

(* Exercice 1.2.3 nth *)

let nth r l =
  let rec nth_rec r l c =
    match l with
      |[] -> failwith "nth: list is too short"
      |e1::l1 -> if c = r then
	  e1
	else
	  nth_rec r l1 (c+1)
  in
  nth_rec r l 0;;

(* Exercice 1.2.4 Search_pos *)

let search_pos r l =
  let rec search_pos_rec r l c =
    match l with
      |[] -> failwith "search_pos: not found"
      |e1::l1 -> if e1 = r then
	  c
	else
	  search_pos_rec r l1 (c+1)
  in
  search_pos_rec r l 0;;

(* Exercice 1.2.5 init_list *)

let init_list n x =
  let rec init_list_rec n x l =
    if n > 0 then
      init_list_rec (n-1) x (x::l)
    else
      l
  in
  init_list_rec n x [];;

(* Exercice 1.2.6 reverse_list *)

let reverse_list l =
  let rec reverse_list_rec l s =
    match l with
      |[] -> s
      |e1::l1 -> reverse_list_rec l1 (e1::s)
  in
  reverse_list_rec l [] ;;

(* Exercice 2.1 - Trajectoire - Midterm Machine Test 2016 *)

let reverse n =
  if n < 0 then
    invalid_arg "n doit etre positif ou nul"
  else
    let rec reverse_rec n l =
      match n with
	|0 -> l
	|_ -> reverse_rec (n/10) (l*10+n mod 10)
    in
    reverse_rec n 0;;

let trajectory x n =
  let rec trajectory_rec x n l=
    if n=0 then
      l
    else
      x::(trajectory_rec ((reverse x)+x) (n-1) (l))
  in
  trajectory_rec x n [];;

(* Exercice 2.2.1 - Goldbach - Midterm Machine Test 2016 *)

let prime n =
  if n < 2 then
    invalid_arg "n doit etre superieur a 2"
  else
    let rec prime_rec c n =
      if n <> c then
	if n mod c <> 0 then
	  prime_rec (c+1) n
	else
	  false
      else
	true
    in
    prime_rec 2 n;;	      
	  
let goldbach n =
  if n < 2 then
    invalid_arg "Goldbach failed: input must be even"
  else
    let rec goldbach_rec n k =
      if prime (k) && prime (n-k) then
	  (k , n-k)
      else
	if k=2 then
	  goldbach_rec n (k+1)
	else
	  goldbach_rec n (k+2)
    in
    goldbach_rec n 2;;

(* Exercice 2.2.2 - Liste de Goldbach - Midterm Machine Test 2016 *)

let prime n =
  if n < 2 then
    invalid_arg "n doit etre superieur a 2"
  else
    let rec prime_rec c n =
      if n <> c then
	if n mod c <> 0 then
	  prime_rec (c+1) n
	else
	  false
      else
	true
    in
    prime_rec 2 n;;	      
	  
let goldbach n =
  if n < 2 then
    invalid_arg "Goldbach failed: input must be even"
  else
    let rec goldbach_rec n k =
      if prime (k) && prime (n-k) then
	  (k , n-k)
      else
	if k=2 then
	  goldbach_rec n (k+1)
	else
	  goldbach_rec n (k+2)
    in
    goldbach_rec n 2;;

let goldbach_list i s =
  let rec goldbach_list_rec i s l =
    match i with
      |i when i mod 2 = 0 && i <= s -> (i, (goldbach (i)))::goldbach_list_rec (i+1) s l
      |i when i mod 2 <> 0 -> goldbach_list_rec (i+1) s l
      |_ -> l
  in
  goldbach_list_rec i s [];;

(* Exercice 3.2.1 - Decompose - Midterm Machine Test # 2017 *)

let length l =
  let rec length_rec l c =
    match l with
      |[] -> c
      |e1::l1 -> length_rec (l1) (c+1)
  in
  length_rec l 0;;

let reverse_list l =
  let rec reverse_list_rec l s =
    match l with
      |[] -> s
      |e1::l1 -> reverse_list_rec l1 (e1::s)
  in
  reverse_list_rec l [] ;;


let nth r l =
  let rec nth_rec r l c =
    match l with
      |[] -> failwith "nth: list is too short"
      |e1::l1 -> if c = r then
	  e1
	else
	  nth_rec r l1 (c+1)
  in
  nth_rec r l 0;;

let decompose x b =
  reverse_list (
  let rec decompose_rec x b l =
    match x with
      |0 -> l
      |_ -> ( nth (x mod (length (b))) b )::(decompose_rec (x / length b) b l)
  in
  decompose_rec x b []);;

(* Exercice 2.3.2 - Recompose - Midterm Machine Test # 2017 *)

let search_pos r l =
  let rec search_pos_rec r l c =
    match l with
      |[] -> failwith "search_pos: not found"
      |e1::l1 -> if e1 = r then
	  c
	else
	  search_pos_rec r l1 (c+1)
  in
  search_pos_rec r l 0;;

let recompose l b =
  let rec recompose_rec l b n c=
    match (l,b) with 
      |([],_)|(_,[]) -> n
      |(e1::l1,e2::b2) -> if c = 1 && e1 > e2 then  
	  failwith "out of base"
	else
	  recompose_rec l1 b (n+(search_pos e1 b)*c) (c*10)
  in
  recompose_rec l b 0 1;;

