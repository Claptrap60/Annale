﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Management.Instrumentation;
using System.Net;
using System.Net.NetworkInformation;

namespace TP0
{
    internal class Program
    {
        public static void HelloWorld()
        {
            Console.WriteLine("Hello World!");
        }

        public static double MyPow(double x, int n)
        {
            if (n == 0)
                return 1;
            if (x == 0)
                return 0;
            if (n < 0)
                return 1 / x * MyPow(x, n + 1);
            return x * MyPow(x, n - 1);
        }

        public static uint MyFact(uint n)
        {
            if (n == 0)
                return 1;
            return n * MyFact(n - 1);
        }

        public static uint MyFibo(uint n)
        {
            if (n < 2)
                return n;
            return MyFibo(n - 1) + MyFibo(n - 2);
        }

        public static string ChangeChar(string s, char c, uint n)
        {
            if (n >= s.Length)
                return s;
            return s.Substring(0, (int) n) + c + s.Substring((int) n + 1);
        }

        public static uint MyGcd(uint a, uint b)
        {
            return b == 0 ? a : MyGcd(b, a % b);
        }


        public static int Absolute(int a)
        {
            return a < 0 ? -a : a;
        }


        public static double MySqrt(double n, uint iter)
        {
            if (iter == 0)
                return 1d / 2d;
            double nPrev = MySqrt(n, iter - 1);
            return (nPrev + n / nPrev) / 2;
        }

        public static string MyReverseString(string s)
        {
            if (s.Length < 2)
                return s;
            return MyReverseString(s.Substring(1)) + s[0];
        }

        public static bool MyIsPalindrome(string s)
        {
            return MyReverseString(s) == s;
        }

        public static void SayHello()
        {
            Console.WriteLine("What's your name?");
            string s = Console.ReadLine();
            Console.WriteLine("Well hello " + s + "!");
        }

        public static void CalcAge()
        {
            Console.WriteLine("What's your year of birth?");
            string s = Console.ReadLine();
            int year = int.Parse(s);
            int age = DateTime.Today.Year - year;

            Console.WriteLine("Looks like you're around " + age + "!");
        }

        public static void CalcRealAge()
        {
            Console.WriteLine("What's your year of birth?");
            string s1 = Console.ReadLine();
            Console.WriteLine("What's your month of birth?");
            string s2 = Console.ReadLine();
            Console.WriteLine("What's your day of birth?");
            string s3 = Console.ReadLine();
            int year = int.Parse(s1);
            int month = int.Parse(s2);
            int day = int.Parse(s3);
            int age = DateTime.Today.Year - year;
            if (month > DateTime.Today.Month || month == DateTime.Today.Month && day > DateTime.Today.Day)
                age--;
            Console.WriteLine("Looks like you're exactly " + age + "!");
        }

        public static void Main()
        {
            
        }
    }
}
