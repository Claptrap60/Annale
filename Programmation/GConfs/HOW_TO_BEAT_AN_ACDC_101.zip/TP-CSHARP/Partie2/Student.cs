﻿using System;

namespace Partie2
{
    public class Student
    {
        private string name;

        public Student(string name/*, ... */)
        {
            this.name = name.ToUpper();
        }
        
        // Static functions

        public static void DisplayNbStudent()
        {
            // TODO
        }
        
        // Methodes

        public void TakeDamage(int damage, bool isMagical)
        {
            // TODO
        }
        
        public void Attack(Student s)
        {
            // TODO
        }

        public virtual void Status()
        {
            // TODO
        }
        
        // Getters & Setters
        
        /* SUPPRIMEZ LES COMMENTAIRES PUIS COMPLETEZ LES GETTERS / SETTERS
        public int Life
        {
            get { return 0; }
            set { life = Math.Max(0, value); }
        }
        
        public string Name
        {
            
        }

        public int Damage
        {
            
        }
        */
    }
}