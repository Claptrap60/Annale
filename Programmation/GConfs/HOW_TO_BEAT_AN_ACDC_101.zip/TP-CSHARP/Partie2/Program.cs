﻿using System;
using System.Collections.Generic;

namespace Partie2
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            // TODO
            // Mettez vos tests ici
        }
    }
}