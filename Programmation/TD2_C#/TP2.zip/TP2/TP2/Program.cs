﻿using System;
using System.Collections.Generic;

namespace TP2
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            // call your functions here like this:
            // Loop.Print_Tree();
            // Debugging.ex1();
        }
    }
}