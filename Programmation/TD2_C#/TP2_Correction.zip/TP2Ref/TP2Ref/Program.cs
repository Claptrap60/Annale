﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Xml.Schema;
using TP2Moul;

namespace TP2
{
    internal class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}