﻿using System;

namespace TP2Moul
{
    public class Correction
    {
        public static void Print_Naturals(int n)
        {
            if (n >= 1)
                Console.Write(1);
            for (var i = 2; i <= n; ++i)
                    Console.Write(" " + i);
            Console.WriteLine();
        }

        public static void Print_Primes(int n)
        {
            for (var i = 2; i <= n; i++)
            {
                var prime = true;
                for (var j = 2; prime && j <= Math.Sqrt(i); j++)
                    if (i % j == 0)
                        prime = false;
                
                if (prime && i != 2)
                    Console.Write(" " + i);
                else if (prime)
                    Console.Write(i);
            }
            Console.WriteLine();
        }

        private static int Fact(int n)
        {
            if (n <= 1)
                return 1;
            return n * Fact(n - 1);
        }
        
        public static bool isStrong(int n)
        {
            if (n == 0)
                return false;
            var s1 = 0;
            var n1 = n;
            while (n1 > 0)
            {
                s1 += Fact(n1 % 10);
                n1 /= 10;
            }

            return s1 == n;
        }

        public static void Print_Strong(int n)
        {
            for (int i = 1; i <= n; i++)
                if (isStrong(i))
                {
                    if (i == 1)
                        Console.Write(i);
                    else
                        Console.Write(" " + i);
                }
            Console.WriteLine();
        }

        public static long Fibonacci(long n)
        {
            long a = 0;
            long b = 1;
            for (var i = 0; i < n; i++)
            {
                long temp = a;
                a = b;
                b = temp + b;
            }
            return a;
        }

        public static long Factorial(long n)
        {
            long temno = 1;

            for (var i = 1; i <= n; i++)
            {
                temno = temno * i;
            }

            return temno;
        }

        public static float Abs(float n)
        {
            return n < 0 ? -n : n;
        }

        public static float Sqrt(float n)
        {
            return (float) Math.Sqrt(n);
        }

        public static long Power(long a, long b)
        {
            long res = 1;
            for (int i = 0; i < b; i++)
                res *= a;
            return res;
        }

        public static void Print_Tree(int n)
        {
            for (var i = 0; i < n; i++)
            {
                for (var j = 0; j < n - i - 1; j++)
                {
                    Console.Write(" ");
                }
                for (var j = 0; j < i * 2 + 1; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            var t = 1;
            if (n > 3)
            {
                t = 2;
            }
            for (var i = 0; i < t; i++)
            {
                for (var j = 0; j < n - 1; j++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine("*");
            }
        }

        public static double ex2(int x, int n)
        {
            double sum = x;
            double no_row = x;
            for (int i = 1; i < n; i++)
            {
                double ctr = (2 * i) * (2 * i + 1);
                no_row = -no_row * x * x / ctr;
                sum = sum + no_row;
            }

            return sum;
        }

        public static bool ex3(int n)
        {
            int i;
            var f3 = 0;

            for (i = 3; i <= n / 2; i++)
            {
                var f1 = 1;
                var f2 = 1;
                for (var j = 2; j < i; j++)
                {
                    if (i % j != 0) continue;
                    f1 = 0;
                    j = i;
                }
                for (var j = 2; j < n - i; j++)
                {
                    if ((n - i) % j != 0) continue;
                    f2 = 0;
                    j = n - i;
                }
                if (f1 != 1 || f2 != 1) continue;
                return true;
            }
            return f3 != 0;
        }

        public static int[] ex4(int[] arr)
        {
            Array.Sort(arr);
            return arr;
        }

        // ex1 debug is juste an infite loop, if it stops you can put points
        // ex2 the sum of [x - x^3 + x^5 - ...] with n number of terms
        // ex3 returns true if the number can be express as the sum of two primes
        // ex4 simple bubble sort, where i changed things around
    }
}