﻿using System;
using System.IO;

namespace Exercise1
{
	internal static class CopyFile
	{
		/// <summary>
		///   EXERCISE 1.3:
		///   <para />
		///   Read the source file and put its content into destination file
		/// </summary>
		/// <param name="source">the path to the source file</param>
		/// <param name="destination">the path to the destination file</param>
		public static void CopyAllFile(string source, string destination)
		{
			string data;
			if (File.Exists(source))
				data = File.ReadAllText(source);
			else
				data = String.Format("could not open file: {0}", source);
			File.WriteAllText(destination, data);
		}

		/// <summary>
		///   EXERCISE 1.4:
		///   <para />
		///   Read the source file and put half of its content into destination file
		/// </summary>
		/// <param name="source">the path to the source file</param>
		/// <param name="destination">the path to the destination file</param>
		public static void CopyHalfFile(string source, string destination)
		{
			if (!File.Exists(source))
			{
				string data = String.Format("could not open file: {0}", source);
				Console.WriteLine(data);
				return;
			}
			string[] lines = File.ReadAllLines(source);
			string[] newlines = new string[lines.Length / 2];
			for (int i = 0; i < lines.Length / 2; i++)
				newlines[i] = lines[i];
			File.WriteAllLines(destination, newlines);
		}
	}
}