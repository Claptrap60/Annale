﻿using System;
using System.IO;

namespace Exercise1
{
	internal static class PrintFile
	{
		/// <summary>
		///   EXERCISE 1.1:
		///   <para />
		///   Read all the text in a file and print it in the console.
		/// </summary>
		/// <param name="path">the path (absolute or relative) to the file</param>
		public static void PrintAllFile(string path)
		{
			string data;
			if (File.Exists(path))
				data = File.ReadAllText(path);
			else
				data = String.Format("could not open file: {0}", path);
			Console.WriteLine(data);
		}

		/// <summary>
		///   EXERCISE 1.2:
		///   <para />
		///   Read only one line out of two and print it in the console.
		/// </summary>
		/// <param name="path"></param>
		public static void PrintHalfFile(string path)
		{
			if (!File.Exists(path))
			{
				string data = String.Format("could not open file: {0}", path);
				Console.WriteLine(data);
				return;
			}
			string[] lines = File.ReadAllLines(path);
			int len = lines.Length;
			for (int i = 0; i < len; i++)
			{
				if (i % 2 == 0)
					Console.WriteLine(lines[i]);
			}
		}
	}
}