﻿using System.IO;

namespace Exercise1
{
	public class Architecture
	{
		/// <summary>
		///   EXERCISE 1.5:
		///   <para />
		///   This function creates a folder architecture as described in the subject.
		///   When testing, take care not to put an important folder in path.
		/// </summary>
		/// <param name="path">the path to the first folder you will create</param>
		public static void Architect(string path)
		{
			string authorsPath = Path.Combine(path, "AUTHORS");
			string readmePath =  Path.Combine(path, "README");
			string tp5Path =     Path.Combine(path, "TP5");
			string uselessPath = Path.Combine(tp5Path, "useless.txt");
			
			if (File.Exists(path))
				File.Delete(path);
			if (Directory.Exists(path))
				Directory.Delete(path, true);
			Directory.CreateDirectory(path);
			File.WriteAllText(authorsPath, "* prenom.nom\n");
			File.WriteAllText(readmePath, "Everything in programming is magic... except for the programmer\n");
			Directory.CreateDirectory(tp5Path);
			File.Create(uselessPath);
		}
	}
}