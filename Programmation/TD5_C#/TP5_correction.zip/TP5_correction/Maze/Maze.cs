﻿using System;
using System.IO;

namespace Maze
{
	internal static class Maze
	{
		/// <summary>
		/// This is where you should call your functions to make your program work.
		/// </summary>
		/// <param name="args">unused</param>
		public static void Main(string[] args)
		{
			// initialize
			string fileIn = AskMazeFile();
			string fileOut = GetOutputFile(fileIn);
			char[][] grid = ParseFile(fileIn);
			int[][] processed = ZeroFilledGrid(grid.Length, grid[0].Length);

			// print before processing
			BonusPrint(grid);
			Console.WriteLine();

			// processing
			Point start = FindStart(grid);
			bool solved = SolveMazeBackTracking(grid, processed, start);
			if (!solved)
			{
				Console.WriteLine("ERROR: could not solve maze!");
				Console.WriteLine("\nPress any key to continue...");
				Console.ReadKey();
				return;
			}
			// print after processing
			BonusPrint(grid);

			// save solution
			SaveSolution(grid, fileOut);

			Console.WriteLine("\nPress any key to continue...");
			Console.ReadKey();
		}

		/// <summary>
		/// Ask the path to the .maze file and check if it is valid.
		/// </summary>
		/// <returns>the name of the input file</returns>
		private static string AskMazeFile()
		{
			string s;
			do
			{
				Console.WriteLine("Which .maze file should be loaded?");
				s = Console.ReadLine();
			} while (Path.GetExtension(s) != ".maze" || !File.Exists(s));
			return s;
		}

		/// <summary>
		/// Get the name of the output file.
		/// </summary>
		/// <param name="fileIn">the name of the input file</param>
		/// <returns>the name of the output file</returns>
		private static string GetOutputFile(string fileIn)
		{
			return Path.ChangeExtension(fileIn, ".solved");
		}

		/// <summary>
		/// Read the file given as parameter and make it a two dimensional array.
		/// </summary>
		/// <param name="file">the name of the input file</param>
		/// <returns>the two dimensional array</returns>
		private static char[][] ParseFile(string file)
		{
			string[] lines = File.ReadAllLines(file);
			int height = lines.Length;
			int width = lines[0].Length;
			if (height < 1 || width < 1 || height * width < 2)
				return null;

			char[][] grid = new char[height][];
			for (int i = 0; i < height; i++)
			{
				grid[i] = new char[width];
				for (int j = 0; j < width; j++)
					grid[i][j] = lines[i][j];
			}
			return grid;
		}

		/// <summary>
		/// Create a grid filled with 0.
		/// </summary>
		/// <param name="height">the height of the grid</param>
		/// <param name="width">the width of the grid</param>
		/// <returns></returns>
		private static int[][] ZeroFilledGrid(int height, int width)
		{
			int[][] grid = new int[height][];
			for (int i = 0; i < height; i++)
			{
				grid[i] = new int[width];
				for (int j = 0; j < width; j++)
					grid[i][j] = 0;
			}
			return grid;
		}

		/// <summary>
		/// Find the start point of the maze.
		/// </summary>
		/// <param name="grid"></param>
		/// <returns></returns>
		private static Point FindStart(char[][] grid)
		{
			bool found = false;
			int height = grid.Length;
			int width = grid[0].Length;
			int i = 0;
			int j = 0;
			while (i < height && !found)
			{
				j = 0;
				while (j < width && !found)
				{
					found = grid[i][j] == 'S';
					if (!found)
						j++;
				}
				if (!found)
					i++;
			}
			if (!found)
				return null;
			return new Point(i, j);
		}

		/// <summary>
		/// Modify the grid to add the path from start to finish to it.
		/// </summary>
		/// <param name="grid">the maze</param>
		/// <param name="processed">the points that have already been processed</param>
		/// <param name="p">the current point</param>
		/// <returns></returns>
		private static bool SolveMazeBackTracking(char[][] grid, int[][] processed, Point p)
		{
			if (p.X < 0 || p.X >= grid.Length)
				return false;
			if (p.Y < 0 || p.Y >= grid[0].Length)
				return false;

			if (processed[p.X][p.Y] != 0)
				return false;
			processed[p.X][p.Y] = 1;

			if (grid[p.X][p.Y] == 'F')
				return true;
			if (grid[p.X][p.Y] == 'B')
				return false;

			if (SolveMazeBackTracking(grid, processed, new Point(p.X - 1, p.Y)))
				grid[p.X][p.Y] = 'P';
			else if (SolveMazeBackTracking(grid, processed, new Point(p.X, p.Y - 1)))
				grid[p.X][p.Y] = 'P';
			else if (SolveMazeBackTracking(grid, processed, new Point(p.X, p.Y + 1)))
				grid[p.X][p.Y] = 'P';
			else if (SolveMazeBackTracking(grid, processed, new Point(p.X + 1, p.Y)))
				grid[p.X][p.Y] = 'P';

			return grid[p.X][p.Y] == 'P';
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="grid"></param>
		/// <param name="fileOut"></param>
		private static void SaveSolution(char[][] grid, string fileOut)
		{
			string[] lines = new string[grid.Length];

			for (int i = 0; i < grid.Length; i++)
				lines[i] = new string(grid[i]);

			File.WriteAllLines(fileOut, lines);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="grid"></param>
		private static void BonusPrint(char[][] grid)
		{
			for (int i = 0; i < grid.Length; i++)
			{
				for (int j = 0; j < grid[0].Length; j++)
				{
					switch (grid[i][j])
					{
						case 'B':
							Console.BackgroundColor = ConsoleColor.Blue;
							break;
						case 'O':
							Console.BackgroundColor = ConsoleColor.White;
							break;
						case 'P':
						case 'S':
							Console.BackgroundColor = ConsoleColor.Red;
							break;
						case 'F':
							Console.BackgroundColor = ConsoleColor.Yellow;
							break;
					}

					Console.Write("  ");
					Console.ResetColor();
				}
				Console.WriteLine();
			}
		}
	}

	/// <summary>
	///   Class that allows to store 2D coordinates.
	/// </summary>
	internal class Point
	{
		public Point(int x, int y)
		{
			X = x;
			Y = y;
		}

		public int Y { get; set; }
		public int X { get; set; }
	}
}