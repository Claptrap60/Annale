﻿using System.Collections.Generic;

namespace EpitaSpaceProgram
{
    public abstract class CompositeBody : Body
    {
        private readonly List<Body> _bodies;

        protected CompositeBody(string name, double mass, double density, Vector2 initialPosition)
            : base(name, mass, density, initialPosition)
        {
            _bodies = new List<Body>();
        }

        protected void Add(Body body)
        {
            _bodies.Add(body);
            Velocity += body.Velocity;
            Acceleration += body.Acceleration;
        }

        public override void Update(double delta)
        {
            // Don't forget to update the base body! Otherwise, the acceleration you set below will not be applied.
            base.Update(delta);

            foreach (var body in _bodies)
            {
                body.Update(delta);
                Acceleration += body.Acceleration;
            }
        }
    }
}