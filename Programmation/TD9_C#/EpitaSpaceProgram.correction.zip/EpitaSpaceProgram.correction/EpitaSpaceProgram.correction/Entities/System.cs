﻿using System;
using System.Collections.Generic;
using System.Linq;
using EpitaSpaceProgram.ACDC;

namespace EpitaSpaceProgram
{
    public class System : IEntity
    {
        private readonly double _g;
        private readonly List<Body> _bodies;

        public System(double g)
        {
            _g = g;
            _bodies = new List<Body>();
        }

        public void Add(Body body)
        {
            _bodies.Add(body);
        }

        private void ApplyEquivalentForce(Body a, Body b)
        {
            var force = _g * a.Mass * b.Mass / Math.Pow(Vector2.Dist(a.Position, b.Position), 2);
            a.ApplyForce(force * (b.Position - a.Position).Normalized());
            b.ApplyForce(force * (a.Position - b.Position).Normalized());
        }

        public void Update(double delta)
        {
            // Don't forget to update all the children bodies *before* applying forces to them!
            // Otherwise some other forces that are applied to them might not work properly.
            foreach (var body in _bodies)
                body.Update(delta);
            
            for (int i = 0; i < _bodies.Count; i++)
            for (int j = i + 1; j < _bodies.Count; j++)
                ApplyEquivalentForce(_bodies[i], _bodies[j]);
        }

        public IEnumerable<string> Serialize()
        {
            return _bodies.SelectMany(body => body.Serialize());
        }
    }
}