﻿using System;
using System.Collections.Generic;
using System.Linq;
using EpitaSpaceProgram.ACDC;

namespace EpitaSpaceProgram
{
    public class DistanceJoint : IEntity
    {
        private readonly Vector2 _origin;
        private readonly Body _body;

        public DistanceJoint(Vector2 origin, Body body)
        {
            _origin = origin;
            _body = body;
        }

        public void Update(double delta)
        {
            // This is not the exact same formula as in the subject, but it is equivalent.
            // To prove it, you can write the formula yourself, expand the variables, and
            // simplify it.
            var fExtB = _body.Acceleration;
            var p = _body.Position - _origin;
            var lambda = (-Vector2.Dot(fExtB, p) - Vector2.Dot(_body.Velocity, _body.Velocity)) /
                        Vector2.Dot(p, p);
            // We could have removed the mass multiplication and just applied an acceleration change.
            _body.ApplyForce(lambda * p * _body.Mass);
        }

        public IEnumerable<string> Serialize()
        {
            return new List<string>();
        }
    }
}
