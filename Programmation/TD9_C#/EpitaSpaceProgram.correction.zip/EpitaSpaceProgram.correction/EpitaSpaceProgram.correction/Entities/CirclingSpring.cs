﻿namespace EpitaSpaceProgram
{
    public class CirclingSpring : CompositeBody
    {
        public CirclingSpring(string name, double mass, double density, Vector2 initialPosition, Vector2 origin, double spring)
            : base(name, mass, density, initialPosition)
        {
            // Rotating by 90 degrees to the left isn't just the application (X, Y) -> (Y, -X).
            // This only works if you are rotating relative to the *actual* origin of the system (0, 0).
            // Here, `origin` represents the equilibrium point of the spring. As such, to rotate, we must
            // first translate the position so that the origin is actually at (0, 0), then do the inverse
            // translation.
            var initialPositionY = initialPosition - origin;
            initialPositionY = new Vector2(initialPositionY.Y, -initialPositionY.X) + origin;
            Add(new Spring("", mass, density, initialPosition, origin, spring));
            Add(new SpringMax("", mass, density, initialPositionY, origin, spring));
        }
    }
}