﻿using System;
using System.Net.NetworkInformation;

namespace EpitaSpaceProgram
{
    public class Infinity : CompositeBody
    {
        public Infinity(string name, double mass, double density, Vector2 initialPosition, Vector2 origin, double spring)
            : base(name, mass, density, initialPosition)
        {
            var initialPositionY = (initialPosition - origin) / 2;
            initialPositionY = new Vector2(initialPositionY.Y, -initialPositionY.X) + origin;
            Add(new Spring("", mass, density, initialPosition, origin, spring));
            // * 4 because we want the spring to run twice as fast as `springX` over half the displacement.
            Add(new SpringMax("", mass, density, initialPositionY, origin, spring * 4));
        }
    }
}