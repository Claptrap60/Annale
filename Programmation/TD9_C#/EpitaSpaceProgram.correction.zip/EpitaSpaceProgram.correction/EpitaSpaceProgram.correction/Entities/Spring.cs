﻿using System;

namespace EpitaSpaceProgram
{
    public class Spring : Body
    {
        protected Vector2 Origin { get; }
        private readonly double _spring;
        
        public Spring(string name, double mass, double density, Vector2 initialPosition, Vector2 origin, double spring)
            : base(name, mass, density, initialPosition)
        {
            Origin = origin;
            _spring = spring;
        }
        
        public static Vector2 GetForce(Vector2 position, Vector2 origin, double spring)
        {
            Vector2 displacement = position - origin;
            return -spring * displacement;
        }
        
        public override void Update(double delta)
        {
            base.Update(delta);

            ApplyForce(GetForce(Position, Origin, _spring));
        }
    }
}