﻿using System;

namespace EpitaSpaceProgram
{
    public class SpringMax : Spring
    {
        public SpringMax(string name, double mass, double density, Vector2 initialPosition, Vector2 origin, double spring)
            : base(name, mass, density, initialPosition, origin, spring)
        {
            var a = initialPosition - origin;
            var w = Math.Sqrt(spring / mass);
            Velocity = -a * w * Math.Sin(Math.PI / 2);
            Position = origin;
        }
    }
}
