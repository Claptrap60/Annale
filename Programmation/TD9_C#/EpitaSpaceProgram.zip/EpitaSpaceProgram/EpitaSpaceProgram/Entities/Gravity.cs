﻿namespace EpitaSpaceProgram
{
    public class Gravity : Body
    {
        public Gravity(string name, double mass, double density, Vector2 initialPosition, Vector2 gravity)
            : base(name, mass, density, initialPosition)
        {
            // FIXME
        }

        public override void Update(double delta)
        {
            // FIXME
        }
    }
}