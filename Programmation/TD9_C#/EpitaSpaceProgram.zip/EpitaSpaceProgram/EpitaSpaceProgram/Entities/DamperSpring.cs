﻿namespace EpitaSpaceProgram
{
    public class DamperSpring : Spring
    {
        public DamperSpring(string name, double mass, double density, Vector2 initialPosition, Vector2 origin,
            double spring, double damping)
            : base(name, mass, density, initialPosition, origin, spring)
        {
            // FIXME
        }

        public override void Update(double delta)
        {
            // FIXME
        }
    }
}